<?php
$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "ToolboxCN";

$resultJSON = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 
$sql = "SELECT json FROM resourceList";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
         $resultJSON = $resultJSON . $row["json"];
    }
} else {
    $resultJSON = "0 结果";
}
// echo $resultJSON;
$conn->close();
?>
<!DOCTYPE html>
<html>
  <head>
	<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
	<title>ToolboxCN-资源中心</title>
 <script src="http://cdn.bootcdn.net/ajax/libs/eruda/2.3.3/eruda.js"></script>
<script>eruda.init();</script>
 <link rel="stylesheet" href="./css/mui.min.css">
 <style type="text/css">
			.mui-preview-image.mui-fullscreen {
				position: fixed;
				z-index: 20;
				background-color: #000;
			}
			.mui-preview-header,
			.mui-preview-footer {
				position: absolute;
				width: 100%;
				left: 0;
				z-index: 10;
			}
			.mui-preview-header {
				height: 44px;
				top: 0;
			}
			.mui-preview-footer {
				height: 50px;
				bottom: 0px;
			}
			.mui-preview-header .mui-preview-indicator {
				display: block;
				line-height: 25px;
				color: #fff;
				text-align: center;
				margin: 15px auto 4;
				width: 70px;
				background-color: rgba(0, 0, 0, 0.4);
				border-radius: 12px;
				font-size: 16px;
			}
			.mui-preview-image {
				display: none;
				-webkit-animation-duration: 0.5s;
				animation-duration: 0.5s;
				-webkit-animation-fill-mode: both;
				animation-fill-mode: both;
			}
			.mui-preview-image.mui-preview-in {
				-webkit-animation-name: fadeIn;
				animation-name: fadeIn;
			}
			.mui-preview-image.mui-preview-out {
				background: none;
				-webkit-animation-name: fadeOut;
				animation-name: fadeOut;
			}
			.mui-preview-image.mui-preview-out .mui-preview-header,
			.mui-preview-image.mui-preview-out .mui-preview-footer {
				display: none;
			}
			.mui-zoom-scroller {
				position: absolute;
				display: -webkit-box;
				display: -webkit-flex;
				display: flex;
				-webkit-box-align: center;
				-webkit-align-items: center;
				align-items: center;
				-webkit-box-pack: center;
				-webkit-justify-content: center;
				justify-content: center;
				left: 0;
				right: 0;
				bottom: 0;
				top: 0;
				width: 100%;
				height: 100%;
				margin: 0;
				-webkit-backface-visibility: hidden;
			}
			.mui-zoom {
				-webkit-transform-style: preserve-3d;
				transform-style: preserve-3d;
			}
			.mui-slider .mui-slider-group .mui-slider-item img {
				width: auto;
				height: auto;
				max-width: 100%;
				max-height: 100%;
			}
			.mui-android-4-1 .mui-slider .mui-slider-group .mui-slider-item img {
				width: 100%;
			}
			.mui-android-4-1 .mui-slider.mui-preview-image .mui-slider-group .mui-slider-item {
				display: inline-table;
			}
			.mui-android-4-1 .mui-slider.mui-preview-image .mui-zoom-scroller img {
				display: table-cell;
				vertical-align: middle;
			}
			.mui-preview-loading {
				position: absolute;
				width: 100%;
				height: 100%;
				top: 0;
				left: 0;
				display: none;
			}
			.mui-preview-loading.mui-active {
				display: block;
			}
			.mui-preview-loading .mui-spinner-white {
				position: absolute;
				top: 50%;
				left: 50%;
				margin-left: -25px;
				margin-top: -25px;
				height: 50px;
				width: 50px;
			}
			.mui-preview-image img.mui-transitioning {
				-webkit-transition: -webkit-transform 0.5s ease, opacity 0.5s ease;
				transition: transform 0.5s ease, opacity 0.5s ease;
			}
			@-webkit-keyframes fadeIn {
				0% {
					opacity: 0;
				}
				100% {
					opacity: 1;
				}
			}
			@keyframes fadeIn {
				0% {
					opacity: 0;
				}
				100% {
					opacity: 1;
				}
			}
			@-webkit-keyframes fadeOut {
				0% {
					opacity: 1;
				}
				100% {
					opacity: 0;
				}
			}
			@keyframes fadeOut {
				0% {
					opacity: 1;
				}
				100% {
					opacity: 0;
				}
			}
			p img {
				max-width: 100%;
				height: auto;
			}
		</style>
  </head>
  <body>	
  <header class="mui-bar mui-bar-nav">
	 <h1 class="mui-title" id="resourceName">资源名称</h1>
  </header>
  <div class="mui-content">
  <div class="mui-card">
<div class="mui-card-content">
<div class="mui-card-content-inner">
  <div id="slider" class="mui-slider">
			<div class="mui-slider-group mui-slider-loop">
				<!-- 额外增加的一个节点(循环轮播：第一个节点是最后一张轮播) -->
				<div class="mui-slider-item mui-slider-item-duplicate">
					<a href="#">
						<img src="" class="img4" data-preview-src="" data-preview-group="1">
					</a>
				</div>
				<!-- 第一张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img class="img1" data-preview-src="" data-preview-group="1" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADICAYAAACH6F8xAAAAAXNSR0IArs4c6QAAIABJREFUeF7tfQuYXEWVf53b3TMJr80AIQTURf+LyhsWFhFWEcGVVURBiCIYTDJd53YCUVFEVsVhVUBQ0ZCZvlU9ySwsshpF8bkKKj4XXcXHqqxvEQIBAkkQA2Sm+57/d9ru3s7MdPetqnv7Men6vvlmkqlz6tS5fabqVp3z+4Ho0bZhw4aBzZs3751KpfZOp9NDxWJxbwDYWwjBX0P8nf8dhmH5OwAMEVH19/cCwL1E9HkAuFNK+dMedYMYHx//OyHEomKxuHVwcHDLE088sXX16tU7enU+u4rd0OmJjo6O7pFOp/cmoqFKgJSDgwPG87xyANUFTC2ohBB7xGT7tjAMz8rlct+MSV/iaoIgWAEAq4QQzxNC7DbLgE8KIbYIIbY2+k5EWwBgK3/xz6lUauvw8DDL9FsbPBBb4I2Pj++9Y8eOvTOZTDlYqitN/QpUDaLKylTuJ4QYaMM8Ww6RyWQOW758+T0tO3a4g1LqI0KItyZoRsNg5SDmQC2VSltTqdQWXmUzmcyWbdu2bb300ku3J2jTnFPdMPC01keHYfhMg+1brzvnHs/zXp7NZjd260SUUtSttgkheHtbDtrqKsrfwzDc6nnelvrvHLRTU1Nb582bt+W+++7bOjIyUuzieSVi2k6Bp5R6ARGtBICXCiGekciI3a30ekS8pBtNVEr9UAhxXDfaFoNNf64EbXnbW9kCbyEi3gqXv3Pw8kqbTqfLQbvnnntuueCCC1iuJ1st8LTW5xNRXgixZ0/OJCajETG27XdMJgmtdZ6I/Lj0zSE9pWbvsdX32+nvswMDA1uXLVv2dCf9UP6QKaVyQoixThrSLWN3W+AppYaFEIVu8c8csoMPoJodPtVW2erWmE+Nh4eHWcZ5yw9jY2NDqVTqrsoJ2Rzyq9VUnkbE+VaSCQjxezYR/SQB1X2Vbh7gLXF5G9zsfZa3xo1Oy0EpNSKEeK+bHXNG+h5EPKxbZqOU4kOHVLfY07fDygNPCCG+AgBfkFL+e1UDBEFwMwCcb6Vy7glNIOLybpiW1voeIjqkG2zp2xCbB65FxMtYG694PxNCHBmb6h5WRESn+b7/9U5PQSl1qxDi7E7b0R8/EQ9o5IOELr8bSmTmDZTejIhvbOeAs42ltb6ciK7qtB398ZPzgOd5x3HgPVbJIElupO7X/KjneS/OZrP/20lTlVL/JIT4aidt6I/dFg9oDrzfCiE40XZXbpcg4vWddACn3JVKpQeFEIOdtKM/dls88BPQWv+AiI5vy3BdOAgAfFVKeXqnTQuC4OcAcHin7eiPn7wHiOghXvH+UwjR8Q/etOk+JYTYVve1mYg2CyEeAQD+2hyGIX/ndyHrNCoi4uP6U33f/3by7m48QhAEnwGAs1xtAIA7iOhDdfm1O1V28P9Pq/TIuI7Zl7fzAAfex4UQb7ATbyrF2erl4AEALr15nL8TUfnf/P9hGG7mQOKAKhaLmycnJx+55JJLOOhatiAIrgKAy1t2bNKBiK72ff9fXHS4ymqtryGi8hGzSyOi+wcGBk5avnz5/VH1cE3j448/PhSGYbkkq1QqcX1jtWqkVdBGHabfb6YHtnDg3SCEuMjUOwDwvTAMb6sGk+d5HEgcVFt37NixefXq1YklsBYKhZeEYXiHECJtandd/7vnz59/8tKlSztWzlLJj73ZYQ41USL6J9/32SdtaUqpv0mlUgsqQbuA6ymrBciz1FBWC5D5+y6dC1x5OL/nd7wriegKi6f1K0TsyAVvEARfAoBXWNhcEwGAc6SUfF/WkaaUej4A/IiIdo/BgIsRcW0MehJXsWbNmkFeVdPp9ALP88oBCwDl70S0YBpSQH3A8s/zEjewPQP8kFe8twghbE70NiPifu2x8/9G0Vq/mYg+6jjuOCJmHXU4iSulOAfzaCclfxVei4gXx6Cn61Vcf/31C+bNm7eAV9Zq0PJ3IUT5/zhwq4FcuSKrD9xuSr27nVPGlgLAjRZeDxGxrZMJguBQz/P4AOEAC3urIr8Lw/BluVzuXgcdTqJKqQ1CiHOdlPxV+HZEfHkMeua0iomJCV4pFzz55JNcEFAOUl5lK1vj2r+nBW5168y/j7t9AvL5/Bme533BRnO7S2iUUuuFEMtsbK3KEFHO9/3ARYeLrFLqA0KIOA50fpPJZE4zOUxxsXtXlZ2YmFhQLBbLgTo1NVULWP43n0QT0UkWvsnzO96JRPQ9C2HBp2ArV67k+qTEWxAE5wHALY4D3YqI5zjqsBbP5/Nv8jxvwlpBRRAAJsMwPKOdhymuNs9FeaUUZzo932JuH+B3PBa0SpVKpVIHDw8P/85iYCMRpdS+QoivCSGOMhLcuTNfXbxSSskQCm1vlT9wfGe6VwyD98xhSgxz7VoVWutHiGihqYEA8Dbeau7ned7DpsKV/icg4g8sZSOLxXTXdQUivi/yoDF2VEoxBB9f0h/rqpaIPub7Ph+I9VuHPaCUYugJz9QMIloOIyMj6cWLF0+ZCnN/Inql7/tftpGNKhMEwakAwKudS/va0NDQ6UuWLGFHtb1prW8hovNcByaiz/m+/xpXPX35eDxgW9njed5rqpgrj9tsgQBgaX1VbTzT2VmL1vp2InqZg+5Jz/POymazif6BaGSfwz3pdJU/y2Qyr+ofpjh8EmIUrSS1c2WPcSOik6uB90chxEHGGoR4KyK63qk1HDYIgksA4MMWdtVEiOgjvu+/zUWHrWwQBBcAQK3c31aPEOJxIjq3f5ji4MGYRYMgOBgAfmOjNgzDI6qBd7cQ4u9NlQDA+6WU7zGVi9J/fHz88FKpxLDq+0Tp36DPD4vF4pmrVq16yEGHlShjlAoheJXlS1zXxkXL2lVJXz4+DxQKhRPCMGSQMOMWhuEzqoHHOX6nGWsQIo+IKy3kWorEgQVDRBf6vn9Ty8ES6KCU4vfSU11VA8DVUso47v1cTenL13nA5f57+/btu5UDT2v9SSJaYupZItrg+/7rTOVa9Y9ji0ZE63zfZ0zKtjelFG9tPxTDwJ9AROdDmRjs6KuY5gGl1IVCiH+zcMxTiFgLPFuk4q8jos1K2dDeyvUGbzFdErB5730OIv7cwjHOIkqp7wsheKtp3Yjo+6VSacmqVasil/lYD9YXNPaAw/nDg4h4YHWraZvG9FNEPMbY6iYCcbDhENFq3/e53KkjTSnFweLCPfGQ53lLstnsdzoygf6gLT3gkPr3C0SsHa7Ybo3uR8RntbQyYoc4wH6I6NO+78eRgBzR6pndbO93qpqI6OO+719gbUBfMHEPKKU43xdNByKi7/i+/+LqO95yficyVSKEeBIR46gnKw+tlOIt5skWdlRFHuZ31U5DOSil/ksI8UKHeXByQseuQVzs3lVklVKfFkK81nS+APA5KWXtAp2zIT5rqoT7x1WhoJR6pxDiahsb6laK9/i+/34XHXHIBkEwCgBxnPa+AxGvi8Omvo54PRAEwZ0A8BJTrUT0b77vLyuveEEQvBgAvmWqhPun0+m9VqxYwfjw1o3JOTiXkYisYQEqQD/nIiJn4XS0xZTmVp5DJ69EOurELh9cKfU/QogjTM0EgI9IKd9WDrx8Pn+453lWJ4CZTOZZrmlMSqlrhRCXmk6irv8OAFgipfy8g45YRZVSfJ0QR8YM/yFZgoi3x2pgX5mTB5RSzBx8oIWSdyPiB8qBd8MNNxwwMDDwgIUS/ot8tO/7zL9g1a677rrd99prr79YCVeEGNLO932XwHUZflZZRvDatm3b54kojgrx31TeXa39HPsEd3GFSikGyeKqE6MGAKuklGPlwOPS+MnJyUiwetNH8Tzv1Gw2+w2j0es65/P5l3ied6etPMsBwDcGBweXXHjhhVZJqy5jN5Ndu3bt32YyGV6F4yCF+XYYhufmcjmGQ+y3DnvA9uQaAM6TUn6iRjtsG8GVbdCnbP0QR+BVxn6gst3kE8WuaZWcTQ6+OIChPoWIxhlGXeOMOWLIunXr9iwWi1bwlWEYnp7L5b5aH3hWl74AkJNSWmOYxBh45ccKAMuklDapPIl9LJRS1qfG040CgBuklKsTM7avuKUH8vn8QZ7ncUWPcQOA4xkFoT7wbHnyyi+LxhZUBEZGRgYWL17MBwhxYiZeg4hOKNO282kkFwSBDwD5mPQ6+TwmG3ZZNYVC4dgwDH9k44BisXjwqlWrflcLPK31nURkfC/BmJyIeImNEVWZIAhu5KJaFx3TZYnos4ODg29YtmzZ03HqddEVJ+2153nD2WzWJunBZQp92b8meljTqaVSqX2Gh4e31K94ViykAHCTlJIzta1bBQiIeeH2sFYyu+AvK6eB98Ss11qdUkoJIaS1gv8TfCoMwyW5XO6LMejqmApePUql0pEA8CwA2IuJZJiURgjx+1Kp9JNO4p82ckqhUDgvDEMrxLtqwkl94BWEEDZlNF9CxDNcn1zc73p19hQrH1CrzBzXec2yEjOk4m1CiDNj0P1Hz/POzWazXMjcM01r/Q9CCE5T5JSrVihd/MfzVgBYh4j3dcMkgyC4GADWWNiyFRHLhdH1gfdBIcQ7TJUBwPellE55idUxtdaHEdEvTG2I0h8A3iml5Dl2vCmlFgshPieE4A+gU+PyoUwm89oVK1YwqWVXN6UUJ9TzeYBtAvj1Q0ND71qyZInV1VdcznF4Zfg9IpZJYOvf8S4jomssjPstIj7XQq6hiANQaCszJhBxeatO7fh9Pp8/xvM8Dr5nxjDebVLKswGAYtCViIoKIDGffrviiv7B8zw/m822jRlpukNsGbaEED9CxPIf2/rAyxKRDa7HFkR0wUWZ9UErpfhKwOndcTbFTC9WKpUu6IZ3hyAImBD0CwDgQjdWnaZCRD+RqHFUqrV+OxHFmuwNACuklAzp3/bmANdY47qoBV4QBOcAgNVFeFwVCrP8ZckJIcYS8OyjRPR63/e/noBuI5VBECwDgLg+QFci4oiRAQl3jhEGY4alnbqzVUrxQSCfbJq2GpRHLfDy+fxLPc+z+iAODQ3tltS+e3x8/JhSqfRj0xlG6d9pApOqjVrry4mIaaWdm2tCg7MBdQq01kuI6JNx6pyui4hOa/cfUKUU3+HZoILXwMHqt5pHExFzthm3dDp9YJIv90xmODg4yPwOzzY2rrWA8z1k6yFa99BaryGiOHjuip7nnZPNZvn9sWMtn88fWKl4YbqrJNvvt2/ffkRUCu84DFFKMV/I/7PQ9QFEfDfL1Z9q8onTnyyUcZrW4VLKX9rImsg47K2bDgMAXwaA5dls1pZDwmQaDfvGyJv3QCqVOnt4ePi/YzHMQonW+kYiijUpopEZAPAxKWXb+CSUUo9a4r2+HRHLAM21wBsdHd0jnU7bFrS+CBG/a/F8jEViYoSdMS4AMGHlUt/3rUBKjScyi8CaNWsWDg4OfkYI8Y+u+gDg7nQ6fZZrraSNHfl8/njP8xIns5lm2yGI+Csbe01lXMhKfN8v07TVAo//oZTaIYQYMDWEiM70fd+K3NJ0LO4fBMELASCRKgQAuEBK+XEbu+KQqSBo82V/+b7HpfFKfvDBB7/6lFNOKbroMZXVWo8T0QpTOZf+7WJRqrz22KYhnoWInDwxI/A2CSH2N3VAJ06XKqsDv5PaVAG3muIIIl7ZqlNSv9dan0ZE/IDiAJJaj4htC4INGzaktmzZ8gQAzE/KPw30bkbEOEqvmpq9bt26A4rFom3R+MlVIK7pKx6/px1q4bDa3tVC1klEa/3pSuqRk55ZhG9Jp9O+K56MrVFa6/OJ6GZb+WlyVyHiu2LS1VRNoVB4RRiGX2rHWNPHYPAhKaUVdlBUe8fGxo5MpVJWSACpVOqI4eHhcmbW9MBjAFXj94tO4/srpRj2gXFb4m5385bJBdrCxaCY78DawiKrlGKUt7YE+Sy+vRwRbbKvIj8mpdQpQggrxAUmK8nlcuXVcnrg8RG0TfKuZjqbyNYn0NGlVKOFOU8Q0Zt83+dDj7a3IAiuA4C3xzEwAJwjpeQqlMSaUsr2MxSHTTcj4hvjUNRIh0uiSf19906Bp7We4A+ZheG3IuI5FnKxioyNjT0nlUoxb0GrjHfjcQHgUillHEQkxmMrpZhjzzaxuH68RwDgLCllIgdTPJBS6qeOXPXG/qkKAMA3pZS8IiXWlFK8wNggLjyNiLX33umB92EiMi5qbceETTwZBAHnPzqXKs0yZn5oaOjidlM6T0xMLJicnGTkYmfaLyHEzz3Pe3U2m7WCLmj1HLTWDxDRAa36JfT7nyEiY7Qm1pRSTJlmjLgAAA9KKWsHgdO3mrw3t0Fi/jkixoGkFZvDgiB4NwC8LzaF/6fo64wSLaW0YgO1tUcp9XwhBAffYbY66laGOzKZzJlJVOcHQbAJAIxPxl3nxPKceeX7vjHBqsnYDqQ6v0TEw2vPoH5QpZRVUvL0aDaZSJJ9tdavZRKTBMbYSERZ3/e/koDuhiq11icTEb9rOrPMxoEcMJuhSinbk/E4XBk7bdx0o2xhSqpkJbMGntb69UT0HxYe2IGIcYIVWZgwu0gQBEdV4On/JjalFUVVcNK49TbTFwTB6wDgE3GMCQAflFIyZ0VsTWv9lZhAfI1tAoB/k1IuMxY0ELB9jamSlTRa8axBXIaGhgaXLFkyaTCHtnWtoFXzSmFTytHUzk6w+gRB8GYA+GgcDgSAt0gpPxaHLtbhsBWLw4TLEDGJa6WabUopqyu3KlnJrIEXBMFxAPBDGw94nrd/p5OMW9ldKBTeH4ZhEndMt3med3E2m2U8/bY0rfVVRBQLhCEAvE5KuSEOw+NckU3taccFulKKL8CN37OrZCWzBl7lOP73phOu9G9bkqqlfWUxrfWbiKicqBpz+wURrWonN59Sigto49habSOiV8dh+9q1a/fJZDKcvd/uVgMSSnJgW7ISItqJQm6nU83rr79+wW677bbVxnAiOrGTmf0mNiulODuHMTvifi+dIiKsZqCb2GTTt1JRwivVP9vIT5P5VSXZ/beuuoIguA0AXu2qx1C+LdAXtlQH088Ddgo8nqhtyQMAvEJK+Z+GzupY99HR0f0zmcx/WIL4NrUbAN4vpXxPOyanlOKCTA6+OI7R7ywWi2euWrXKib0pn8+f4Xle26pV2M9VaPQkfT4yMuItXry4ZDMGEb3B9/3aweVsgcdgovtaKD8fEa1APi3Gik0kCII1ABBH5fd0m25JpVIXM2pwbMY2UJTP50/yPI/xchg20LXdgojnuypRSvGO4jRXPRHlY7G51Vjr169fODU1ZcXWBACnSykZq6XcZgu8XwshbOD6LkLE0VbGd+PvtdYXE5ENQGmr6fyAg5pJKlp1dP19EARne57HlRoznqmF7g8jolN+aIUlidP3km5Pl0qlw1auXPmHpAeqJDEwBIlxm74iz3hIQRDcBQAnmGoGgPdKKf/VVK5b+mut/5mIGA7di9mmzYyl4vt+oqA/bLPWeiURxfLHL46CYKUUAyQnCiLcTpi/8fHxk0qlkhXSQiqVOnh4eJixWmZf8bTWXyKiV1h8+NYg4pst5LpGJAiCgwHgRiFELMjY9RMDgH+RUl6d9GSVUvzHL473y3tSqdSLXLfKQRDkASApvM+21RnycwuC4NUAUK4gN21VspKGgWebCQ8AH5dSxpFBbzqnuPtDEATrAcCmSqOpLUS0bnJyctXq1asZYiOxFhcxShiGy3K5nDPXoFLKlpejmY+uQ0RjygEXp2utme/BiqEJEXknVUP6nu0dj7MYbIgPv4KIcRxru/gmNlmllG3CeFMbuJKjWCyuSPKdpIILwiedNrWV9fbHtovRWl9JRFfE8YAA4G1Syo/EoctEh0PB9Yw7xtkC771CCBs04h8i4vEmE+n2vkkBsgLArVLKROsXmX89nU5v4Jd6Wz/HXe4VBMErAICBe4+ysYnh94none1CtJtuo9b6GiK6zNR2IvqD7/s74XDOCDyHE74/IKINyKfpPNraXynF92OcIWL1YWlkbNL3Tvl8fj/P83jVO9nBYYkc0+fz+azneQzA9IKItn0rDMNCLpfrGPob26m11lyVEtHm+m41spKG73gOIDuPI+ICC6O6XmTNmjV7DQ4OcvAxn1tcLVF8kJgONRKltK4cz/MfBv6jxsSU5c8PEW0BgHuFED8tFovfTHJbbvIwgyD4FMNnmMhU+tbIShoGXmU7YIUSNTQ0lG53dbaFE6xFgiC4BgCMtxoNBvw8IiaSVuWwa6k3dXsqlTqhiopl7bQ5JOiQFPBJRHx9vStmbDXHxsZOSKVStmjKCxGxEwmybXu8SilmzeVTOtdWY45xVVQvX8Hk5OJf1/rDth7Vx+mDpHTFQVbSbKv5XCLi7BXjNv2S0FhBjwhUKsF56/kcB5Nj38ZViEL4ve5EB7tY9Lvz588/fenSpdsd9cwpcQeykhl/xGY71eQ8Tc7XNG5JHxgYG5SgQOVDzsFnVVwLAOdJKWOpJK9OMybo9G1CiNMRsd3cBwk+rXhUx0FW0nDFc8nAFkK8HBFvj2ea3a/FpeizWCwevGrVqloKkets4wK/bWcKluuc2y3vULkzg7121oRapRTX5BmfUFZYVhPPSWy3wxuNp5RaK4RYZWFPrEWblTzTL1vYMV2kK7gCY5hH7CpcalWFEDWykoYrHv9CKcVV6MbvL93CsBq71xsoVEoxhr4xrCEA3CGltNqiTjcln88fVLmvK5PaO7TbpZSnA0AtrclB15wTrdQ9Wu1QiKhGVtIq8LiM5TgL7yV6N2VhT6IiSimrDykRXe37PgOjOreYCCAfTKVSL+9fHTR+HI6cf0ci4s/rtTfaatqSq1+LiHHdczl/KJNUoJQ6QgjxPzZjAMDZUkrmwHNqSimG5nOueEjioMdpYl0o7LKdrycrabXicYn6Thd+UXwBAOuklHzPNeebS+1bsVh81qpVq+53cZJLicq0cWu83C72zHVZrfUbiegmy3nujohPtlzxtNajRLTSYpDbEPEsC7meE1FKWf1xEkJsRMRnuky4UjfIhymurLG7zPNy8TfLKqWYY/16Cz07kZU0XfG01u8jonebDgIA35FSvthUrhf7O8C8fdH3/Ve5zFlrfQsRneeiQwjxu0wm8/Lly5cnDpngaGdXiNsWGDeiN2j0jvdWIYRNvdM9iGgM9tkVnjUwYmRkJL148eIpA5H6rk40z0opri53hthg+D0p5ect57DLiWmt1zCEh8XEdyIrabriKaUuFELYVB4/jIgdYYqxcIi1iAsrqOd5r8xms1Z3bi6kiNMm+y5E5Lq4fovoAaUUv98Zk1422gXOuuIFQfAqALD5a1hExEzEufRstyAIrgCAK20mEIbholwuZwwRt379+kOnpqa+LYTYx2bcOplEauwcbep6cVuyEiHErFUojbaajLTM5AzGbWBgYGjZsmWc7zdnm0N5yK8RkXnujBpD9hUKhS9aglDVxiKiXwwODr5s2bJlDxkZ0O/MhytWZCWNGIwarXiHAgDznBk3z/OekxTbqLExCQkopZ4QQuxhof5TiLjEVM72xX76OADwMinl10zH7/cvn2pakZXwSSgizmBZnjXwGN48nU5vsnT4sYj4Y0vZrhcrFAqLwjC0XTGMM3uCIDgPAOJA6H4rIsZC7dX1DykBAx1OsXciK6maNmvgjYyMDCxevNgKgo6ITvN9/+sJzL0rVBYKhXPCMGS4dONm6hut9dFEdHcMILvjiGiDFWI8x7kqYEtWIoSYFWG9Idy37XaKiM71fT8J+uOueKZKKVv4Qya72AcRH48ykQ0bNgxs3br1mzGA6/5w9913P+2CCy74c5Rx+31mekAptZsQwqooeDpZSdMVj3+plPoTA9BYPIgsIo5byPWEiNb6R0R0rIWxP0bEyHJKKc6S4GwJpwYAJ0kp/8tJyS4urJTiOOB4MG7TyUqiBN5PhBBHG48kxDsQ8ToLuZ4Qsa1IMOHnDoJgaQVK3sknACCllHHgwzjZ0evC+Xz+GM/zrM4twjB8QS6X++/pPmi41QyC4OsA8FJTp8VZ8mI6dtL9tdaH8ZG85TiXIGLLXD+t9T8Q0YwHZTFmbCjQFmPPKZEKgBTTjhm3RjhEDQNPa/0pIjLGECSiwPf9nLGFPSAQBIEPAHlLU1/UCgG5wvDKtZDGd331NhHRd573vOe99JRTTila2toXq/OAC8TH1NTUvhdddNFjkVc8B+KLRGDruuGToJRiJOM3mNpCRH8eHBxctGzZsqebySqlOE2P0/WcGgAcI6X8qZOSvnDNA0opXkjGbFwipfRmq+pvdqrJBZZcaGnavoaILzMV6oX+DvBu30XEF7UIOuuHW683Dl67XngW7bRRa305Ednktm5DxKHZbG0WeJcKIa61mKDR6Z2F/o6IcNqW1jq0GZyIxnzfbwiKpLU+kYi+Z6N7mkzsWJ0x2NTzKpRSHAccD6atIZ9Iw8ArFAorwjA0vhYAgD9JKQ8ytbDb+wdB8GIA+JalnYiIejbZsbGxoVQqxfS+iyx1l8WI6A7f92MBUHKxYy7KxklWUvVPs8OVs4joMxaO3I6INnmMFkO1T8SFL68Z0K9S6nMx8Ng9DQBHSSl/0z6P7Doj2ZKVNEOTaxZ4JxMRZ04Yt3Q6vdeKFSs4kXjONAeK6k1SygNne8FWSjHS2AdcnRQXeJKrHXNV3qEaZQZZScsVb2xs7MhUKsW4kTbtbxHxPhvBbpVRSjGsPcPbGzUi+qrv+6dPFwqC4FQAiKNS4ApEfJ+RUf3ORh6wJStpdrXW7B3vGWEYWiFhEdHRvu/bBq2RU9rRef369QunpqaMi1crts3g6mbSyFQqdT8RDTjanxjVl6Ndc0rc4TS7IeNSs1NN68TQMAxPyeVyVtvUbnxiQRCczfTJNrYR0Rt937+5XlZr/W0ianq9EGGsbZ7nHZHNZjdG6Nvv4uCBOMlKWm41uYNS6ikhxDwLm2dgxVvo6BoRpRT6PUFVAAAUpUlEQVQDPzEAlE3bCUU4CILrAODtNorqZRol37rq7cvv7AGlFEOZcOKDZ+qbZgQwDVe8SuA9IIQ4wHRAIlru+/6EqVy39tdaf5eITrKw73eIeHBVLkaworcj4oct7OmLGHpgYmJi/8nJSdui8IYLUKvAY7z3ww1t5Tult/m+bwMPaDpUW/orpSaFEDYgTp9BxDJv+ujo6DPT6bTzgRMAbJBSvq4tE+8PIlwS4wHgJVLKWe9+WwUeCxkD1BLR+33fZ/zHnm+jo6OHpNPpeywnUsPQVEpZ/RGbNu5DqVTqsOHh4S2W9vTFDD1QYf+1Pa+YQVZSHb5V4DGxxmsMbeXuaxHRBvzTYqhkRZRSkl93bUYJw/DsXC732ZiYWoXneS/OZrNW6G829vdlyucc/Pm3IpjxPO+ZjQ6/WgXeOiHEctMHAAAfl1JeYCrXjf2VUrY+ICI6mGsaiWjWdDHD+a5ERNuSJMOh+t2rHgiCYBkAMOW2TZtBVhJpxbM9gQOAL0spX2ljabfJOGwRf1YqlZY6JCHUXAEAN0kpncuFus23vWCPUsqWzmAHIja8EWi64jmUQ9yFiCf2gmNb2WgL9SCE+HchBFfwH9hqjBa/v3dgYOCQVrV8jmP0xRt4wAHTdBMiNrwRaLXVRCFEYPFUfoOIz7OQ6yoRpZQ1orYQghPMz3adkOd5x2WzWYb467cOeCBuspJIW02l1LlCiA2m8yWix3zfN85rNB0n6f5BEFwGANckPU4T/W9CxBs7OP4uP7QtWYkQomnxc9MVzzGRt+GLZa88TaUUp4k5r1qW89VcxGcp2xeLyQNxk5VEWvHGx8ePKZVKtrBmz8jlcpz50rNNKcVJ4s9o9wQA4H+llIe2e9z+eDM9YEtWIoS4ERHf1MinTVe8fD5/kOd5f7R5IABwuJTSivjEZry4ZdauXbtPJpN5NG69UfR5nndoNpvlqvR+67AH4iYribTirVmzZq/BwcFIkOOz+KclnF2Hfdp0eJeLU8d5LUFEK24Gx3H74rN4wJasBADeI6V8v9WKx0JBEEwBQNr0qRDRmb7vf8FUrlv6B0FwFQBc3k57AOBjUkpn2PZ22jzXx4qbrCTSisedlFIPCyH2M3UwEV3o+z7T1/ZkU0pxdfipbTT+J4j4920crz9UCw+4vG54nveGbDb7H9YrnlKK3zWMkY2J6C2+7zOzTk82pRSz6+zZLuNTqdRBw8PDVsQY7bJxVxtHa/1cIvq1zbyJ6J993/+KS+Ax3qNNFkotM9/G8E7KuDjc0u4zEPFLlrJ9sYQ8MDY2dkIqlbrLRn0jspLIW03be4xefl9RSnFeJMOpJ94A4INSShvE7sRt29UHCILgdAD4Txs/ENFzfd//rfWKp7W+kYiWmg7ey4m9WutRIlppOmeL/nMmp9Vi7l0vorV+PRE1fE9rNoFGZCWRVzwHgsQvIOKZXe/dWQxUSjFjz3FJ257JZPZbvnw5wwb2Wxd6IAmyEpPA40ryfzX1CwB8R0ppXL1uOk4S/R0qEiKb43neqdls9huRBfod2+4Bh+qchmQlJoHHZBtrLWb9C0Q8wkKuoyKFQuGEMAytXqgNDL8SEUcM+ve7dsADSZCVRA68QqFwXhiGt1jM+wFEbHueo4WdO4kopVYLIRK7BgGAb0gp23k/6OqSXVbegazkbkRs+qrSNFeTPa61fjkRNbyPaPJUnt6xY8eC1atX7+ilJ6e1vpmIzk/I5uL8+fMXLF26dHtC+vtqY/RAEmQlkVc8F05uz/P2z2aznPnSM00pxUfAf5eEwQBwkpTyv5LQ3dcZvwdsyUqIaIPv+00hGFuueKOjo3+XTqcb3ke0mO4hiPir+F2SjMaJiYkFk5OTW5PQDgDvlFJ+MAndfZ3JeMCWrAQAAiklM/w2bC0Db3x8fO9SqTSDPD3KVInoRN/3kz6oiGJKpD4uF6ZNnTyHwJ8iOXKOdEqCrCTyVpM72h6vE9Erfd//cq88hyAIrgCAK2O29y9Syr1m48eLeZy+upg9YEtWAgCXSik/5LTiVQKPV7y9TecVhuEFuVzu46ZyneqvlPqiECJWWMJUKvX3w8PDP+nUnPrj2nmgUovKrx2xkpWYrni2Bw4XIeKo3dTbL6WUYg68hXGNDABvkVImdjURl519PTM9MD4+/relUuleG99UEcSdVzyt9Q+I6HhTI4joPb7vN6zCNdWXZP9CofDsMAz/EOMYNcISU51KqcVCCAY6YiZZ/nl/IQRTWz8khGDmGv4q/wwAm0ql0kNEtGlwcPDBuUaBbeq7uPoHQXAUAPzURl8zshLTFY8ztGfQCbcyCgA+IqV8W6t+tr+vfEAXA8ABRMTgofz1IBE9mkql/mSCRxkEwesA4BO2ttTLAcBmKaVx8XBlWz8CANnKfGzMebIanET0kOd55UANw7AWtPPnz9944YUXWh2Y2RjUizL5fP4lnufdaWN7qVQ6auXKlf/jvOIppfg97Q0WRkwgojH3QoWq+IAwDA9IpVKL+XtdcDEyM3/xKtCqac/zdJQAVEq9SwgRy+psC1bkkg3fyhGz/D6srpy8WnKAcqBWgxYAHiCijYhoyw1nYVL3iLhg7jQjKzFd8W4QQlxk6hYA+KyUsoZLqZTa1/O8A0ql0jM8zzswDMPadwDgYOIUswWm40TofwIi/qBZP6WULWr2dLU+IhqzCxUKhSPDMLxdCLEownza3YVXxxnbXCLi3cXGTCazcePGjQ+MjIwU221YUuMlRVZiFHha6yuJ6ArTSQLAN4mIg4mDar6pfIz9706lUv/UjFdOa/1aIvq045i3IKJVupkDOYajybGKz9jmhmHIq+lGDtC6VZT7dXVzeB5NyUpMA+/NRPTRrvZUC+OI6GO+7zdE8HLZ01eGvh8Rn2XrI9tKf9vxOiw32za3vLXlIC2VSg/Mmzdv47Jly7Z1ys6kyEpMA++NRNSziGE8WSL6he/7DcuUXHFWPM97TjabtQL/ZftskxQ69cFs47j121xGJuev2uoZhuHGXC7H10CxNgeyknsQ8bBWxrRMGat8KPhSmS+Xe7qFYfjsXC43693MunXr9iwWi4wsZtM2I6LVKWZ1MK01/8VvSOtkY9QuJlPe5gIAv3fWVs8wDB9IpVIbOViz2SwHLUXxS1JkJUYrXhAELwSAns+qB4DjpZQM6zBrc4DrFmEYnpLL5Wy5snnF+5EQ4tgoH4p+HycPVLe5HIzl1bP6vfoeumPHjo0DAwOfBoAzLEaKBHkSacVbt27d84rFYs9UGTRyVrMVr7Kyv1cIYVUZTkRjvu9ztb5VU0rxSSjzrfdbb3ugKVmJ0YrH92qe5/VUXd1sz+7Pf/7zHpdeemnDItRCoXBIGIb3WD53p+1moVA4NgxDXvX6rbc9cD0iXtJqCpFWvJGRkfTixYunWinr8t9H4ptTSnHGgRVWTAzbzf6q1+UfogjmXYGI72vVL1LgsZIgCB4HgL1aKezW30elNFZKWaGq8bxdt5uV7S5vdXnL22+96YFIhQGRA08pxUflB/WmL8RliHhtFNsd32edtptV+7TW5xPRkgppyu5R7O736RoPnI+ILcHBTALvbiFEr7HZ/B4ALpFSft7ksSilOCv9KBOZal8iOtn3/W/byM4mwxf7qVRqfyIqf3met4i/V3JVq9/jGq6vx9EDrchKqupNAu8OIcRpjnYlKc7HxOV8QiLivMyvAMC3EdGYWNMlYTqO7aaJk0ZGRryFCxful8lk9g/DkAOzFqQAUA7MuoBNIg/WxNxdoW/LvGB2QuTAC4LgkwDA2592N65D48yER4joEc6i5/w/viitq03bFGcWfSdPN5N07ujo6B7z58/fr1Qq7cdBygFZDU7+Pm0lHUzSlrmquxVZifGKp7XOE5Efo8P4eqIcUEKI8s8AUP25XENWKpUeTCIdKMoclFIM13B0lL7T+3ie98JsNvt9G9lukeErJOZ2ICIO1EUAwF8zVtMurabomBvnzZu3b5Rax8grnlLqA0KIfzGdEQB8LwxD5vR+JJVKPVwsFnnVeggRHzXV1c7+Drj5sZxutnOuLmMppXYLw7AcpMVikUuaOHWO731nexf9G5exekF206ZNqZGREX7tadpMAo8ryZsiJzUY6VeIeEgrQ7rt9+vXrz90amrql5Z2xXK6aTl214pxPSavoLx68vdKgJZX1cphUW1VFUL03FYXALZJKYeiPIDIgedQGNizH0KllMtJ7rGI+OMoD6HfZ2cPTExMzJucnKwF6CxBWg1UPjxySk6P2fd/RMTnRNEZOfAKhcKrwzC8LYrSaX1CRExZyHVcJAiCywDgGhtD2n26aWPjXJBhwOUdO3Ysqr6PciByoHqeV11JyytrZUVNOgGkJVlJ1ecmgfeiMAyt7qc2bdqU6UVYgHw+f7jneT+3/ID27EpvOd+uFtuwYcPA5s2beSu7XzqdrgVlgyDld9WMxYS+hogviyIXOfC01odxMWkUpdP7hGG4qFOnkzb21su4sMOmUqkjhoeHrXzmandf3t4DtgkUUchKjFe8CpQe353ZtJ4iL5kWeO8QQtiSjaxBxDfbOKwv0zkP2BYlRyErMQ68ygvvUzbu6GV6qrGxsSNTqdTPbOYthOhvNy0d10kxpRR/zueZ2kBEV/u+H+nKLfJWk41QSnEt226mBoVh+KpcLtez0BG2SNrsp1Kp9PyVK1f+2tRn/f6d84At/k0UshLjFa8SePdXsC+NvEJEF/q+37NgSUqpdwohrjaadKUzAHxISnmpjWxfpv0ecKSlG/Z9f10Uq01XPN5yHRlF8bQ+b0XEnoUHdMHR7283LT4tHRRRSj1fCPG/NiYAwNlSys9GkTUKvCAI7mRChiiKp/V5HyIaA+JajJOYiNb6LiI6wWYAV+g/mzH7MnYeCILgxQDwLRvpKGQltlvNW4UQNUj2qMbNhctkl9xNIcRViMjcDP3W5R4IguAcAODcYuPmed5R2Wy2KVmJbeAVhBDDxhYJ8UlEfL2FXNeI5PP5YzzPs00B659uds2TbG5IEAQrAcCK0zEKWYlt4PF9Ft9rmbbIN/qmitvZXyn1PSHEiTZjMkFLLpdjHMd+62IPKKWsMW9aodjVT9v0Hc82d/HHiNjzYK0ulelCCCZ+qdYflmsPU6nUI82IVLr48zlnTVNKMYPvaosJRiIrsVrxtNZMmKhNjQKAP0kpexUoqTZdpRRjznDFQpyNoSk4IDdXC4M5KMMwLAcp/8xfk5OTD1100UV9Msk4PT+LLq31jUS01HQY5hb0fZ/ZeyM1oxXPgcrqL4jImeGRcOsjWd6hTi7bzRhM5gSGnVbNCiTGZg7USpA+NDU19WA/SO287cDaFImsxGrFU0qdIoT4hs2Upqam9u3Eh2Ht2rX7eJ63LwDsm06nnwjDkFeWRxHRCqBXa/1uImoJWGrjo5hlnq4L0hmrKQCUgaH6Qbqz15VS3xFC/KPFs/guIr4oqpzRiudykRwVBKaZ4Uophg7Yd/oXAOwz/f+IaGHl/2aoJKL7AeBaRFwb1VHVfkEQHAcADYlPTPV1Q38iKlbwbmaspqVS6WHP88rAUrtCkCqlGHXgUIvnEomsxGrFW79+/TOnpqbuszCKRXaCPbvpppt2n5ycZCiAfUul0kLP8xaGYbgQABZy0PB3XqWqPxNR7NB0AHBHOp32ly9f/geTOSmlmDnphSYyc6UvAFD1kIiINlcDllfQUqnE7K89HaS2lQlCiEhkJVaBx8Hy1FNP/cXyQ8SrBK9C/NVN6MjfFUKcYYK/qbW+goiutPTDLiVGRI9NW00fZmjGbgzSCkcIw0kaVyYIIT6KiG+N+nCNtpqsVCm1QwgxEHWAHul3KyKeE9XWfD5/vOd5DJrbbzF6gMGC6q5cGPKxjJ/ariB1rDmNRFZiteKxUBAE7AwGmZkzDQAmM5nMIhPObaUU42a+YM44ofcm8hcOUgDgAC1vb12D1BFZ7mKTMwObFc/25bPbH+1ZiBgZzMklw6HbHTEH7ePC1vIK2ixI582b9/xSqcSvHjYtElmJ9YrncNxqM5l2yrwLEa+KOuDNN9+81/bt2++yPAGLOky/X494ICpZiUvgfU4IcWaP+COymQAgpZScBB65Vei0bo4s0O84lz0QiazEOvCCIJgAgDfNNQ8S0Wt83+c/KkYtCILLASDySmmkvN+5Zzxgek9t/I6ntf4wEbXkeO4Zj/2VyfXXAPCPtnwOzGHneR4fJXORcNKgqb3k2l3J1oUmnx/jwFNKXSSEuGEueRQAVkgp18cxp0KhcCwRPatCecXAqHwCzN/rfzYGjIrDtr6O5DwQlazEeqvpeOSa3MztNX8CEc+zFzeXXLNmzV4DAwOLKkSSNQosDs4KZ12VaYeDtefIO8w90vMSjyOiUWaV8YrHLnLIZ+s2D1+JiFz42LVtYmJiweTkJBNIlgO1wrSz0/e61TTdtROZ24ZFJiuxXvFYUGvtE1G+R33JVwC3A8BdUsqv9ugcZjX7xhtv3GfHjh21IOWArAbqtK0ub3+t/ujOJX/FNRcAuFtKeZyJPmvnK6X4PY/f9zrZtgghuDj0UQB4jPMC638mokc9z3usVCo9Nm/evEcnJycfsy0H6uQkkxibGV/ryCNr759V5tfqtrfLaLCScEUcOj+FiEY05daBV9lyjgAAV6Uf4Gg9M2hy0MwIIv4/AHg0DEP+Xv59JpN57L777nssCvOmo127vDgRgdZ6p61u/epZ/05aKc/aFX22BBGNkMmcAq8SfFzujkR0JAAw2C2f6JWDpT6YKv9XCyz+Pa9E6XT6sT7uyNz4rHJ2/6JFi8oHQ5z7Wj3ZrX6ftu2NxJzaA565FxGfbWqnc+CZDtjv3/cAe2DNmjWDg4ODtQOj6YdG1VWV/7/L70aziDhu+lT7gWfqsX7/tntgw4YN8x9//PHyfSif7E47KKq/H+XftbPW88OI+HYbh/QDz8ZrfZmu9cDo6OgenLTAB0e8WnqeVw7UWe5HOWDnO0yEoUMus5XvB56t5/pyPe8BxvCZ7X50eqBWTn+5Mp3r/v4YhuG1uVyOwY2t2/8Hr+rCOm3min8AAAAASUVORK5CYII=" id="img1">
					</a>
				</div>
				<!-- 第二张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="" class="img2" data-preview-src="" data-preview-group="1">
					</a>
				</div>
				<!-- 第三张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="" class="img3" data-preview-src="" data-preview-group="1">
					</a>
				</div>
				<!-- 第四张 -->
				<div class="mui-slider-item">
					<a href="#">
						<img src="" class="img4" data-preview-src="" data-preview-group="1">
					</a>
				</div>
				<!-- 额外增加的一个节点(循环轮播：最后一个节点是第一张轮播) -->
				<div class="mui-slider-item mui-slider-item-duplicate">
					<a href="#">
						<img src="" class="img1" data-preview-src="" data-preview-group="1">
					</a>
				</div>
			</div>
			<div class="mui-slider-indicator">
				<div class="mui-indicator mui-active"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
				<div class="mui-indicator"></div>
			</div>
   		</div>
           <br>
           <p id="resourceName1">资源名称</p>
           <font size="3" color="green">免费</font>
  </div>
  </div>
  </div>
  <div>
 <div class="mui-card">
				<div class="mui-card-header mui-card-media">
					<img src="" id="authorImg"/>
					<div class="mui-media-body" id="author" onclick="">
						作者
						<p>null</p>
					</div>
				</div>
				<div class="mui-card-content" id="briefIntroduction">
					简介
				</div>
			</div>
   </div>
   </div>
   <div class="mui-card">
<div class="mui-card-content">
<div class="mui-card-content-inner">
   <iframe src="" style="width:100%;height:500px;" id="CommentSystem"></iframe>
   <button type="button" class="mui-btn mui-btn-success mui-btn-block" style="width:95%;height:40px;line-height:9px;right:-9px;" onclick="download()">免费下载</button>
  </div>
  </div>
  </div>
  </div>
 <script src="./js/mdui.min.js"></script>
 <script src="./js/mui.min.js"></script>
 <script src="./js/mui.zoom.js"></script>
 <script src="./js/mui.previewimage.js"></script>
  <script>
  var downloadURL = "";
 function getQueryVariable(variable){
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i=0;i<vars.length;i++) {
        var pair = vars[i].split("=");
        if(pair[0] == variable){return pair[1];}
    }
    return(false);
}
window.onload = function (){
mui.init();
mui.previewImage();
var slider = mui("#slider");
slider.slider({
	interval: 3000
});
var id = getQueryVariable("id");
if(id == (false)){
document.body.innerHTML = "资源不存在！";
}else{
document.getElementById("CommentSystem").src = ("./CommentSystem/index.php?id=" + id);
const data = <?php echo $resultJSON; ?>;
if(data == null || data == "" || data == undefined || data == "0 结果"){
document.body.innerHTML = "数据库加载失败";
}else{
for (let i = 0; i < data.length; i++) { 
  const item = data[i]; 
  if(item["id"] == id){
    //id符合
  const name = item["name"];
  const type = item["type"];
  const pictures = item["pictures"];
  const author = item["author"];
  const authorImg = item["authorImg"];
  downloadURL = item["downloadURL"];
  document.getElementById("resourceName").innerText = name;
  document.getElementById("resourceName1").innerText = name;
  document.getElementById("briefIntroduction").innerText = item["briefIntroduction"];
  if(pictures.length == 0){
  for (let i = 0; i < 4; i++) {  
    const imgs = document.getElementsByClassName("img" + i);
    for (let i1 = 0; i1 < imgs.length; i1++) {  
     imgs[i1].src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADICAYAAACH6F8xAAAAAXNSR0IArs4c6QAAIABJREFUeF7tfQuYXEWVf53b3TMJr80AIQTURf+LyhsWFhFWEcGVVURBiCIYTDJd53YCUVFEVsVhVUBQ0ZCZvlU9ySwsshpF8bkKKj4XXcXHqqxvEQIBAkkQA2Sm+57/d9ru3s7MdPetqnv7Men6vvlmkqlz6tS5fabqVp3z+4Ho0bZhw4aBzZs3751KpfZOp9NDxWJxbwDYWwjBX0P8nf8dhmH5OwAMEVH19/cCwL1E9HkAuFNK+dMedYMYHx//OyHEomKxuHVwcHDLE088sXX16tU7enU+u4rd0OmJjo6O7pFOp/cmoqFKgJSDgwPG87xyANUFTC2ohBB7xGT7tjAMz8rlct+MSV/iaoIgWAEAq4QQzxNC7DbLgE8KIbYIIbY2+k5EWwBgK3/xz6lUauvw8DDL9FsbPBBb4I2Pj++9Y8eOvTOZTDlYqitN/QpUDaLKylTuJ4QYaMM8Ww6RyWQOW758+T0tO3a4g1LqI0KItyZoRsNg5SDmQC2VSltTqdQWXmUzmcyWbdu2bb300ku3J2jTnFPdMPC01keHYfhMg+1brzvnHs/zXp7NZjd260SUUtSttgkheHtbDtrqKsrfwzDc6nnelvrvHLRTU1Nb582bt+W+++7bOjIyUuzieSVi2k6Bp5R6ARGtBICXCiGekciI3a30ekS8pBtNVEr9UAhxXDfaFoNNf64EbXnbW9kCbyEi3gqXv3Pw8kqbTqfLQbvnnntuueCCC1iuJ1st8LTW5xNRXgixZ0/OJCajETG27XdMJgmtdZ6I/Lj0zSE9pWbvsdX32+nvswMDA1uXLVv2dCf9UP6QKaVyQoixThrSLWN3W+AppYaFEIVu8c8csoMPoJodPtVW2erWmE+Nh4eHWcZ5yw9jY2NDqVTqrsoJ2Rzyq9VUnkbE+VaSCQjxezYR/SQB1X2Vbh7gLXF5G9zsfZa3xo1Oy0EpNSKEeK+bHXNG+h5EPKxbZqOU4kOHVLfY07fDygNPCCG+AgBfkFL+e1UDBEFwMwCcb6Vy7glNIOLybpiW1voeIjqkG2zp2xCbB65FxMtYG694PxNCHBmb6h5WRESn+b7/9U5PQSl1qxDi7E7b0R8/EQ9o5IOELr8bSmTmDZTejIhvbOeAs42ltb6ciK7qtB398ZPzgOd5x3HgPVbJIElupO7X/KjneS/OZrP/20lTlVL/JIT4aidt6I/dFg9oDrzfCiE40XZXbpcg4vWddACn3JVKpQeFEIOdtKM/dls88BPQWv+AiI5vy3BdOAgAfFVKeXqnTQuC4OcAcHin7eiPn7wHiOghXvH+UwjR8Q/etOk+JYTYVve1mYg2CyEeAQD+2hyGIX/ndyHrNCoi4uP6U33f/3by7m48QhAEnwGAs1xtAIA7iOhDdfm1O1V28P9Pq/TIuI7Zl7fzAAfex4UQb7ATbyrF2erl4AEALr15nL8TUfnf/P9hGG7mQOKAKhaLmycnJx+55JJLOOhatiAIrgKAy1t2bNKBiK72ff9fXHS4ymqtryGi8hGzSyOi+wcGBk5avnz5/VH1cE3j448/PhSGYbkkq1QqcX1jtWqkVdBGHabfb6YHtnDg3SCEuMjUOwDwvTAMb6sGk+d5HEgcVFt37NixefXq1YklsBYKhZeEYXiHECJtandd/7vnz59/8tKlSztWzlLJj73ZYQ41USL6J9/32SdtaUqpv0mlUgsqQbuA6ymrBciz1FBWC5D5+y6dC1x5OL/nd7wriegKi6f1K0TsyAVvEARfAoBXWNhcEwGAc6SUfF/WkaaUej4A/IiIdo/BgIsRcW0MehJXsWbNmkFeVdPp9ALP88oBCwDl70S0YBpSQH3A8s/zEjewPQP8kFe8twghbE70NiPifu2x8/9G0Vq/mYg+6jjuOCJmHXU4iSulOAfzaCclfxVei4gXx6Cn61Vcf/31C+bNm7eAV9Zq0PJ3IUT5/zhwq4FcuSKrD9xuSr27nVPGlgLAjRZeDxGxrZMJguBQz/P4AOEAC3urIr8Lw/BluVzuXgcdTqJKqQ1CiHOdlPxV+HZEfHkMeua0iomJCV4pFzz55JNcEFAOUl5lK1vj2r+nBW5168y/j7t9AvL5/Bme533BRnO7S2iUUuuFEMtsbK3KEFHO9/3ARYeLrFLqA0KIOA50fpPJZE4zOUxxsXtXlZ2YmFhQLBbLgTo1NVULWP43n0QT0UkWvsnzO96JRPQ9C2HBp2ArV67k+qTEWxAE5wHALY4D3YqI5zjqsBbP5/Nv8jxvwlpBRRAAJsMwPKOdhymuNs9FeaUUZzo932JuH+B3PBa0SpVKpVIHDw8P/85iYCMRpdS+QoivCSGOMhLcuTNfXbxSSskQCm1vlT9wfGe6VwyD98xhSgxz7VoVWutHiGihqYEA8Dbeau7ned7DpsKV/icg4g8sZSOLxXTXdQUivi/yoDF2VEoxBB9f0h/rqpaIPub7Ph+I9VuHPaCUYugJz9QMIloOIyMj6cWLF0+ZCnN/Inql7/tftpGNKhMEwakAwKudS/va0NDQ6UuWLGFHtb1prW8hovNcByaiz/m+/xpXPX35eDxgW9njed5rqpgrj9tsgQBgaX1VbTzT2VmL1vp2InqZg+5Jz/POymazif6BaGSfwz3pdJU/y2Qyr+ofpjh8EmIUrSS1c2WPcSOik6uB90chxEHGGoR4KyK63qk1HDYIgksA4MMWdtVEiOgjvu+/zUWHrWwQBBcAQK3c31aPEOJxIjq3f5ji4MGYRYMgOBgAfmOjNgzDI6qBd7cQ4u9NlQDA+6WU7zGVi9J/fHz88FKpxLDq+0Tp36DPD4vF4pmrVq16yEGHlShjlAoheJXlS1zXxkXL2lVJXz4+DxQKhRPCMGSQMOMWhuEzqoHHOX6nGWsQIo+IKy3kWorEgQVDRBf6vn9Ty8ES6KCU4vfSU11VA8DVUso47v1cTenL13nA5f57+/btu5UDT2v9SSJaYupZItrg+/7rTOVa9Y9ji0ZE63zfZ0zKtjelFG9tPxTDwJ9AROdDmRjs6KuY5gGl1IVCiH+zcMxTiFgLPFuk4q8jos1K2dDeyvUGbzFdErB5730OIv7cwjHOIkqp7wsheKtp3Yjo+6VSacmqVasil/lYD9YXNPaAw/nDg4h4YHWraZvG9FNEPMbY6iYCcbDhENFq3/e53KkjTSnFweLCPfGQ53lLstnsdzoygf6gLT3gkPr3C0SsHa7Ybo3uR8RntbQyYoc4wH6I6NO+78eRgBzR6pndbO93qpqI6OO+719gbUBfMHEPKKU43xdNByKi7/i+/+LqO95yficyVSKEeBIR46gnKw+tlOIt5skWdlRFHuZ31U5DOSil/ksI8UKHeXByQseuQVzs3lVklVKfFkK81nS+APA5KWXtAp2zIT5rqoT7x1WhoJR6pxDiahsb6laK9/i+/34XHXHIBkEwCgBxnPa+AxGvi8Omvo54PRAEwZ0A8BJTrUT0b77vLyuveEEQvBgAvmWqhPun0+m9VqxYwfjw1o3JOTiXkYisYQEqQD/nIiJn4XS0xZTmVp5DJ69EOurELh9cKfU/QogjTM0EgI9IKd9WDrx8Pn+453lWJ4CZTOZZrmlMSqlrhRCXmk6irv8OAFgipfy8g45YRZVSfJ0QR8YM/yFZgoi3x2pgX5mTB5RSzBx8oIWSdyPiB8qBd8MNNxwwMDDwgIUS/ot8tO/7zL9g1a677rrd99prr79YCVeEGNLO932XwHUZflZZRvDatm3b54kojgrx31TeXa39HPsEd3GFSikGyeKqE6MGAKuklGPlwOPS+MnJyUiwetNH8Tzv1Gw2+w2j0es65/P5l3ied6etPMsBwDcGBweXXHjhhVZJqy5jN5Ndu3bt32YyGV6F4yCF+XYYhufmcjmGQ+y3DnvA9uQaAM6TUn6iRjtsG8GVbdCnbP0QR+BVxn6gst3kE8WuaZWcTQ6+OIChPoWIxhlGXeOMOWLIunXr9iwWi1bwlWEYnp7L5b5aH3hWl74AkJNSWmOYxBh45ccKAMuklDapPIl9LJRS1qfG040CgBuklKsTM7avuKUH8vn8QZ7ncUWPcQOA4xkFoT7wbHnyyi+LxhZUBEZGRgYWL17MBwhxYiZeg4hOKNO282kkFwSBDwD5mPQ6+TwmG3ZZNYVC4dgwDH9k44BisXjwqlWrflcLPK31nURkfC/BmJyIeImNEVWZIAhu5KJaFx3TZYnos4ODg29YtmzZ03HqddEVJ+2153nD2WzWJunBZQp92b8meljTqaVSqX2Gh4e31K94ViykAHCTlJIzta1bBQiIeeH2sFYyu+AvK6eB98Ss11qdUkoJIaS1gv8TfCoMwyW5XO6LMejqmApePUql0pEA8CwA2IuJZJiURgjx+1Kp9JNO4p82ckqhUDgvDEMrxLtqwkl94BWEEDZlNF9CxDNcn1zc73p19hQrH1CrzBzXec2yEjOk4m1CiDNj0P1Hz/POzWazXMjcM01r/Q9CCE5T5JSrVihd/MfzVgBYh4j3dcMkgyC4GADWWNiyFRHLhdH1gfdBIcQ7TJUBwPellE55idUxtdaHEdEvTG2I0h8A3iml5Dl2vCmlFgshPieE4A+gU+PyoUwm89oVK1YwqWVXN6UUJ9TzeYBtAvj1Q0ND71qyZInV1VdcznF4Zfg9IpZJYOvf8S4jomssjPstIj7XQq6hiANQaCszJhBxeatO7fh9Pp8/xvM8Dr5nxjDebVLKswGAYtCViIoKIDGffrviiv7B8zw/m822jRlpukNsGbaEED9CxPIf2/rAyxKRDa7HFkR0wUWZ9UErpfhKwOndcTbFTC9WKpUu6IZ3hyAImBD0CwDgQjdWnaZCRD+RqHFUqrV+OxHFmuwNACuklAzp3/bmANdY47qoBV4QBOcAgNVFeFwVCrP8ZckJIcYS8OyjRPR63/e/noBuI5VBECwDgLg+QFci4oiRAQl3jhEGY4alnbqzVUrxQSCfbJq2GpRHLfDy+fxLPc+z+iAODQ3tltS+e3x8/JhSqfRj0xlG6d9pApOqjVrry4mIaaWdm2tCg7MBdQq01kuI6JNx6pyui4hOa/cfUKUU3+HZoILXwMHqt5pHExFzthm3dDp9YJIv90xmODg4yPwOzzY2rrWA8z1k6yFa99BaryGiOHjuip7nnZPNZvn9sWMtn88fWKl4YbqrJNvvt2/ffkRUCu84DFFKMV/I/7PQ9QFEfDfL1Z9q8onTnyyUcZrW4VLKX9rImsg47K2bDgMAXwaA5dls1pZDwmQaDfvGyJv3QCqVOnt4ePi/YzHMQonW+kYiijUpopEZAPAxKWXb+CSUUo9a4r2+HRHLAM21wBsdHd0jnU7bFrS+CBG/a/F8jEViYoSdMS4AMGHlUt/3rUBKjScyi8CaNWsWDg4OfkYI8Y+u+gDg7nQ6fZZrraSNHfl8/njP8xIns5lm2yGI+Csbe01lXMhKfN8v07TVAo//oZTaIYQYMDWEiM70fd+K3NJ0LO4fBMELASCRKgQAuEBK+XEbu+KQqSBo82V/+b7HpfFKfvDBB7/6lFNOKbroMZXVWo8T0QpTOZf+7WJRqrz22KYhnoWInDwxI/A2CSH2N3VAJ06XKqsDv5PaVAG3muIIIl7ZqlNSv9dan0ZE/IDiAJJaj4htC4INGzaktmzZ8gQAzE/KPw30bkbEOEqvmpq9bt26A4rFom3R+MlVIK7pKx6/px1q4bDa3tVC1klEa/3pSuqRk55ZhG9Jp9O+K56MrVFa6/OJ6GZb+WlyVyHiu2LS1VRNoVB4RRiGX2rHWNPHYPAhKaUVdlBUe8fGxo5MpVJWSACpVOqI4eHhcmbW9MBjAFXj94tO4/srpRj2gXFb4m5385bJBdrCxaCY78DawiKrlGKUt7YE+Sy+vRwRbbKvIj8mpdQpQggrxAUmK8nlcuXVcnrg8RG0TfKuZjqbyNYn0NGlVKOFOU8Q0Zt83+dDj7a3IAiuA4C3xzEwAJwjpeQqlMSaUsr2MxSHTTcj4hvjUNRIh0uiSf19906Bp7We4A+ZheG3IuI5FnKxioyNjT0nlUoxb0GrjHfjcQHgUillHEQkxmMrpZhjzzaxuH68RwDgLCllIgdTPJBS6qeOXPXG/qkKAMA3pZS8IiXWlFK8wNggLjyNiLX33umB92EiMi5qbceETTwZBAHnPzqXKs0yZn5oaOjidlM6T0xMLJicnGTkYmfaLyHEzz3Pe3U2m7WCLmj1HLTWDxDRAa36JfT7nyEiY7Qm1pRSTJlmjLgAAA9KKWsHgdO3mrw3t0Fi/jkixoGkFZvDgiB4NwC8LzaF/6fo64wSLaW0YgO1tUcp9XwhBAffYbY66laGOzKZzJlJVOcHQbAJAIxPxl3nxPKceeX7vjHBqsnYDqQ6v0TEw2vPoH5QpZRVUvL0aDaZSJJ9tdavZRKTBMbYSERZ3/e/koDuhiq11icTEb9rOrPMxoEcMJuhSinbk/E4XBk7bdx0o2xhSqpkJbMGntb69UT0HxYe2IGIcYIVWZgwu0gQBEdV4On/JjalFUVVcNK49TbTFwTB6wDgE3GMCQAflFIyZ0VsTWv9lZhAfI1tAoB/k1IuMxY0ELB9jamSlTRa8axBXIaGhgaXLFkyaTCHtnWtoFXzSmFTytHUzk6w+gRB8GYA+GgcDgSAt0gpPxaHLtbhsBWLw4TLEDGJa6WabUopqyu3KlnJrIEXBMFxAPBDGw94nrd/p5OMW9ldKBTeH4ZhEndMt3med3E2m2U8/bY0rfVVRBQLhCEAvE5KuSEOw+NckU3taccFulKKL8CN37OrZCWzBl7lOP73phOu9G9bkqqlfWUxrfWbiKicqBpz+wURrWonN59Sigto49habSOiV8dh+9q1a/fJZDKcvd/uVgMSSnJgW7ISItqJQm6nU83rr79+wW677bbVxnAiOrGTmf0mNiulODuHMTvifi+dIiKsZqCb2GTTt1JRwivVP9vIT5P5VSXZ/beuuoIguA0AXu2qx1C+LdAXtlQH088Ddgo8nqhtyQMAvEJK+Z+GzupY99HR0f0zmcx/WIL4NrUbAN4vpXxPOyanlOKCTA6+OI7R7ywWi2euWrXKib0pn8+f4Xle26pV2M9VaPQkfT4yMuItXry4ZDMGEb3B9/3aweVsgcdgovtaKD8fEa1APi3Gik0kCII1ABBH5fd0m25JpVIXM2pwbMY2UJTP50/yPI/xchg20LXdgojnuypRSvGO4jRXPRHlY7G51Vjr169fODU1ZcXWBACnSykZq6XcZgu8XwshbOD6LkLE0VbGd+PvtdYXE5ENQGmr6fyAg5pJKlp1dP19EARne57HlRoznqmF7g8jolN+aIUlidP3km5Pl0qlw1auXPmHpAeqJDEwBIlxm74iz3hIQRDcBQAnmGoGgPdKKf/VVK5b+mut/5mIGA7di9mmzYyl4vt+oqA/bLPWeiURxfLHL46CYKUUAyQnCiLcTpi/8fHxk0qlkhXSQiqVOnh4eJixWmZf8bTWXyKiV1h8+NYg4pst5LpGJAiCgwHgRiFELMjY9RMDgH+RUl6d9GSVUvzHL473y3tSqdSLXLfKQRDkASApvM+21RnycwuC4NUAUK4gN21VspKGgWebCQ8AH5dSxpFBbzqnuPtDEATrAcCmSqOpLUS0bnJyctXq1asZYiOxFhcxShiGy3K5nDPXoFLKlpejmY+uQ0RjygEXp2utme/BiqEJEXknVUP6nu0dj7MYbIgPv4KIcRxru/gmNlmllG3CeFMbuJKjWCyuSPKdpIILwiedNrWV9fbHtovRWl9JRFfE8YAA4G1Syo/EoctEh0PB9Yw7xtkC771CCBs04h8i4vEmE+n2vkkBsgLArVLKROsXmX89nU5v4Jd6Wz/HXe4VBMErAICBe4+ysYnh94none1CtJtuo9b6GiK6zNR2IvqD7/s74XDOCDyHE74/IKINyKfpPNraXynF92OcIWL1YWlkbNL3Tvl8fj/P83jVO9nBYYkc0+fz+azneQzA9IKItn0rDMNCLpfrGPob26m11lyVEtHm+m41spKG73gOIDuPI+ICC6O6XmTNmjV7DQ4OcvAxn1tcLVF8kJgONRKltK4cz/MfBv6jxsSU5c8PEW0BgHuFED8tFovfTHJbbvIwgyD4FMNnmMhU+tbIShoGXmU7YIUSNTQ0lG53dbaFE6xFgiC4BgCMtxoNBvw8IiaSVuWwa6k3dXsqlTqhiopl7bQ5JOiQFPBJRHx9vStmbDXHxsZOSKVStmjKCxGxEwmybXu8SilmzeVTOtdWY45xVVQvX8Hk5OJf1/rDth7Vx+mDpHTFQVbSbKv5XCLi7BXjNv2S0FhBjwhUKsF56/kcB5Nj38ZViEL4ve5EB7tY9Lvz588/fenSpdsd9cwpcQeykhl/xGY71eQ8Tc7XNG5JHxgYG5SgQOVDzsFnVVwLAOdJKWOpJK9OMybo9G1CiNMRsd3cBwk+rXhUx0FW0nDFc8nAFkK8HBFvj2ea3a/FpeizWCwevGrVqloKkets4wK/bWcKluuc2y3vULkzg7121oRapRTX5BmfUFZYVhPPSWy3wxuNp5RaK4RYZWFPrEWblTzTL1vYMV2kK7gCY5hH7CpcalWFEDWykoYrHv9CKcVV6MbvL93CsBq71xsoVEoxhr4xrCEA3CGltNqiTjcln88fVLmvK5PaO7TbpZSnA0AtrclB15wTrdQ9Wu1QiKhGVtIq8LiM5TgL7yV6N2VhT6IiSimrDykRXe37PgOjOreYCCAfTKVSL+9fHTR+HI6cf0ci4s/rtTfaatqSq1+LiHHdczl/KJNUoJQ6QgjxPzZjAMDZUkrmwHNqSimG5nOueEjioMdpYl0o7LKdrycrabXicYn6Thd+UXwBAOuklHzPNeebS+1bsVh81qpVq+53cZJLicq0cWu83C72zHVZrfUbiegmy3nujohPtlzxtNajRLTSYpDbEPEsC7meE1FKWf1xEkJsRMRnuky4UjfIhymurLG7zPNy8TfLKqWYY/16Cz07kZU0XfG01u8jonebDgIA35FSvthUrhf7O8C8fdH3/Ve5zFlrfQsRneeiQwjxu0wm8/Lly5cnDpngaGdXiNsWGDeiN2j0jvdWIYRNvdM9iGgM9tkVnjUwYmRkJL148eIpA5H6rk40z0opri53hthg+D0p5ect57DLiWmt1zCEh8XEdyIrabriKaUuFELYVB4/jIgdYYqxcIi1iAsrqOd5r8xms1Z3bi6kiNMm+y5E5Lq4fovoAaUUv98Zk1422gXOuuIFQfAqALD5a1hExEzEufRstyAIrgCAK20mEIbholwuZwwRt379+kOnpqa+LYTYx2bcOplEauwcbep6cVuyEiHErFUojbaajLTM5AzGbWBgYGjZsmWc7zdnm0N5yK8RkXnujBpD9hUKhS9aglDVxiKiXwwODr5s2bJlDxkZ0O/MhytWZCWNGIwarXiHAgDznBk3z/OekxTbqLExCQkopZ4QQuxhof5TiLjEVM72xX76OADwMinl10zH7/cvn2pakZXwSSgizmBZnjXwGN48nU5vsnT4sYj4Y0vZrhcrFAqLwjC0XTGMM3uCIDgPAOJA6H4rIsZC7dX1DykBAx1OsXciK6maNmvgjYyMDCxevNgKgo6ITvN9/+sJzL0rVBYKhXPCMGS4dONm6hut9dFEdHcMILvjiGiDFWI8x7kqYEtWIoSYFWG9Idy37XaKiM71fT8J+uOueKZKKVv4Qya72AcRH48ykQ0bNgxs3br1mzGA6/5w9913P+2CCy74c5Rx+31mekAptZsQwqooeDpZSdMVj3+plPoTA9BYPIgsIo5byPWEiNb6R0R0rIWxP0bEyHJKKc6S4GwJpwYAJ0kp/8tJyS4urJTiOOB4MG7TyUqiBN5PhBBHG48kxDsQ8ToLuZ4Qsa1IMOHnDoJgaQVK3sknACCllHHgwzjZ0evC+Xz+GM/zrM4twjB8QS6X++/pPmi41QyC4OsA8FJTp8VZ8mI6dtL9tdaH8ZG85TiXIGLLXD+t9T8Q0YwHZTFmbCjQFmPPKZEKgBTTjhm3RjhEDQNPa/0pIjLGECSiwPf9nLGFPSAQBIEPAHlLU1/UCgG5wvDKtZDGd331NhHRd573vOe99JRTTila2toXq/OAC8TH1NTUvhdddNFjkVc8B+KLRGDruuGToJRiJOM3mNpCRH8eHBxctGzZsqebySqlOE2P0/WcGgAcI6X8qZOSvnDNA0opXkjGbFwipfRmq+pvdqrJBZZcaGnavoaILzMV6oX+DvBu30XEF7UIOuuHW683Dl67XngW7bRRa305Ednktm5DxKHZbG0WeJcKIa61mKDR6Z2F/o6IcNqW1jq0GZyIxnzfbwiKpLU+kYi+Z6N7mkzsWJ0x2NTzKpRSHAccD6atIZ9Iw8ArFAorwjA0vhYAgD9JKQ8ytbDb+wdB8GIA+JalnYiIejbZsbGxoVQqxfS+iyx1l8WI6A7f92MBUHKxYy7KxklWUvVPs8OVs4joMxaO3I6INnmMFkO1T8SFL68Z0K9S6nMx8Ng9DQBHSSl/0z6P7Doj2ZKVNEOTaxZ4JxMRZ04Yt3Q6vdeKFSs4kXjONAeK6k1SygNne8FWSjHS2AdcnRQXeJKrHXNV3qEaZQZZScsVb2xs7MhUKsW4kTbtbxHxPhvBbpVRSjGsPcPbGzUi+qrv+6dPFwqC4FQAiKNS4ApEfJ+RUf3ORh6wJStpdrXW7B3vGWEYWiFhEdHRvu/bBq2RU9rRef369QunpqaMi1crts3g6mbSyFQqdT8RDTjanxjVl6Ndc0rc4TS7IeNSs1NN68TQMAxPyeVyVtvUbnxiQRCczfTJNrYR0Rt937+5XlZr/W0ianq9EGGsbZ7nHZHNZjdG6Nvv4uCBOMlKWm41uYNS6ikhxDwLm2dgxVvo6BoRpRT6PUFVAAAUpUlEQVQDPzEAlE3bCUU4CILrAODtNorqZRol37rq7cvv7AGlFEOZcOKDZ+qbZgQwDVe8SuA9IIQ4wHRAIlru+/6EqVy39tdaf5eITrKw73eIeHBVLkaworcj4oct7OmLGHpgYmJi/8nJSdui8IYLUKvAY7z3ww1t5Tult/m+bwMPaDpUW/orpSaFEDYgTp9BxDJv+ujo6DPT6bTzgRMAbJBSvq4tE+8PIlwS4wHgJVLKWe9+WwUeCxkD1BLR+33fZ/zHnm+jo6OHpNPpeywnUsPQVEpZ/RGbNu5DqVTqsOHh4S2W9vTFDD1QYf+1Pa+YQVZSHb5V4DGxxmsMbeXuaxHRBvzTYqhkRZRSkl93bUYJw/DsXC732ZiYWoXneS/OZrNW6G829vdlyucc/Pm3IpjxPO+ZjQ6/WgXeOiHEctMHAAAfl1JeYCrXjf2VUrY+ICI6mGsaiWjWdDHD+a5ERNuSJMOh+t2rHgiCYBkAMOW2TZtBVhJpxbM9gQOAL0spX2ljabfJOGwRf1YqlZY6JCHUXAEAN0kpncuFus23vWCPUsqWzmAHIja8EWi64jmUQ9yFiCf2gmNb2WgL9SCE+HchBFfwH9hqjBa/v3dgYOCQVrV8jmP0xRt4wAHTdBMiNrwRaLXVRCFEYPFUfoOIz7OQ6yoRpZQ1orYQghPMz3adkOd5x2WzWYb467cOeCBuspJIW02l1LlCiA2m8yWix3zfN85rNB0n6f5BEFwGANckPU4T/W9CxBs7OP4uP7QtWYkQomnxc9MVzzGRt+GLZa88TaUUp4k5r1qW89VcxGcp2xeLyQNxk5VEWvHGx8ePKZVKtrBmz8jlcpz50rNNKcVJ4s9o9wQA4H+llIe2e9z+eDM9YEtWIoS4ERHf1MinTVe8fD5/kOd5f7R5IABwuJTSivjEZry4ZdauXbtPJpN5NG69UfR5nndoNpvlqvR+67AH4iYribTirVmzZq/BwcFIkOOz+KclnF2Hfdp0eJeLU8d5LUFEK24Gx3H74rN4wJasBADeI6V8v9WKx0JBEEwBQNr0qRDRmb7vf8FUrlv6B0FwFQBc3k57AOBjUkpn2PZ22jzXx4qbrCTSisedlFIPCyH2M3UwEV3o+z7T1/ZkU0pxdfipbTT+J4j4920crz9UCw+4vG54nveGbDb7H9YrnlKK3zWMkY2J6C2+7zOzTk82pRSz6+zZLuNTqdRBw8PDVsQY7bJxVxtHa/1cIvq1zbyJ6J993/+KS+Ax3qNNFkotM9/G8E7KuDjc0u4zEPFLlrJ9sYQ8MDY2dkIqlbrLRn0jspLIW03be4xefl9RSnFeJMOpJ94A4INSShvE7sRt29UHCILgdAD4Txs/ENFzfd//rfWKp7W+kYiWmg7ey4m9WutRIlppOmeL/nMmp9Vi7l0vorV+PRE1fE9rNoFGZCWRVzwHgsQvIOKZXe/dWQxUSjFjz3FJ257JZPZbvnw5wwb2Wxd6IAmyEpPA40ryfzX1CwB8R0ppXL1uOk4S/R0qEiKb43neqdls9huRBfod2+4Bh+qchmQlJoHHZBtrLWb9C0Q8wkKuoyKFQuGEMAytXqgNDL8SEUcM+ve7dsADSZCVRA68QqFwXhiGt1jM+wFEbHueo4WdO4kopVYLIRK7BgGAb0gp23k/6OqSXVbegazkbkRs+qrSNFeTPa61fjkRNbyPaPJUnt6xY8eC1atX7+ilJ6e1vpmIzk/I5uL8+fMXLF26dHtC+vtqY/RAEmQlkVc8F05uz/P2z2aznPnSM00pxUfAf5eEwQBwkpTyv5LQ3dcZvwdsyUqIaIPv+00hGFuueKOjo3+XTqcb3ke0mO4hiPir+F2SjMaJiYkFk5OTW5PQDgDvlFJ+MAndfZ3JeMCWrAQAAiklM/w2bC0Db3x8fO9SqTSDPD3KVInoRN/3kz6oiGJKpD4uF6ZNnTyHwJ8iOXKOdEqCrCTyVpM72h6vE9Erfd//cq88hyAIrgCAK2O29y9Syr1m48eLeZy+upg9YEtWAgCXSik/5LTiVQKPV7y9TecVhuEFuVzu46ZyneqvlPqiECJWWMJUKvX3w8PDP+nUnPrj2nmgUovKrx2xkpWYrni2Bw4XIeKo3dTbL6WUYg68hXGNDABvkVImdjURl519PTM9MD4+/relUuleG99UEcSdVzyt9Q+I6HhTI4joPb7vN6zCNdWXZP9CofDsMAz/EOMYNcISU51KqcVCCAY6YiZZ/nl/IQRTWz8khGDmGv4q/wwAm0ql0kNEtGlwcPDBuUaBbeq7uPoHQXAUAPzURl8zshLTFY8ztGfQCbcyCgA+IqV8W6t+tr+vfEAXA8ABRMTgofz1IBE9mkql/mSCRxkEwesA4BO2ttTLAcBmKaVx8XBlWz8CANnKfGzMebIanET0kOd55UANw7AWtPPnz9944YUXWh2Y2RjUizL5fP4lnufdaWN7qVQ6auXKlf/jvOIppfg97Q0WRkwgojH3QoWq+IAwDA9IpVKL+XtdcDEyM3/xKtCqac/zdJQAVEq9SwgRy+psC1bkkg3fyhGz/D6srpy8WnKAcqBWgxYAHiCijYhoyw1nYVL3iLhg7jQjKzFd8W4QQlxk6hYA+KyUsoZLqZTa1/O8A0ql0jM8zzswDMPadwDgYOIUswWm40TofwIi/qBZP6WULWr2dLU+IhqzCxUKhSPDMLxdCLEownza3YVXxxnbXCLi3cXGTCazcePGjQ+MjIwU221YUuMlRVZiFHha6yuJ6ArTSQLAN4mIg4mDar6pfIz9706lUv/UjFdOa/1aIvq045i3IKJVupkDOYajybGKz9jmhmHIq+lGDtC6VZT7dXVzeB5NyUpMA+/NRPTRrvZUC+OI6GO+7zdE8HLZ01eGvh8Rn2XrI9tKf9vxOiw32za3vLXlIC2VSg/Mmzdv47Jly7Z1ys6kyEpMA++NRNSziGE8WSL6he/7DcuUXHFWPM97TjabtQL/ZftskxQ69cFs47j121xGJuev2uoZhuHGXC7H10CxNgeyknsQ8bBWxrRMGat8KPhSmS+Xe7qFYfjsXC43693MunXr9iwWi4wsZtM2I6LVKWZ1MK01/8VvSOtkY9QuJlPe5gIAv3fWVs8wDB9IpVIbOViz2SwHLUXxS1JkJUYrXhAELwSAns+qB4DjpZQM6zBrc4DrFmEYnpLL5Wy5snnF+5EQ4tgoH4p+HycPVLe5HIzl1bP6vfoeumPHjo0DAwOfBoAzLEaKBHkSacVbt27d84rFYs9UGTRyVrMVr7Kyv1cIYVUZTkRjvu9ztb5VU0rxSSjzrfdbb3ugKVmJ0YrH92qe5/VUXd1sz+7Pf/7zHpdeemnDItRCoXBIGIb3WD53p+1moVA4NgxDXvX6rbc9cD0iXtJqCpFWvJGRkfTixYunWinr8t9H4ptTSnHGgRVWTAzbzf6q1+UfogjmXYGI72vVL1LgsZIgCB4HgL1aKezW30elNFZKWaGq8bxdt5uV7S5vdXnL22+96YFIhQGRA08pxUflB/WmL8RliHhtFNsd32edtptV+7TW5xPRkgppyu5R7O736RoPnI+ILcHBTALvbiFEr7HZ/B4ALpFSft7ksSilOCv9KBOZal8iOtn3/W/byM4mwxf7qVRqfyIqf3met4i/V3JVq9/jGq6vx9EDrchKqupNAu8OIcRpjnYlKc7HxOV8QiLivMyvAMC3EdGYWNMlYTqO7aaJk0ZGRryFCxful8lk9g/DkAOzFqQAUA7MuoBNIg/WxNxdoW/LvGB2QuTAC4LgkwDA2592N65D48yER4joEc6i5/w/viitq03bFGcWfSdPN5N07ujo6B7z58/fr1Qq7cdBygFZDU7+Pm0lHUzSlrmquxVZifGKp7XOE5Efo8P4eqIcUEKI8s8AUP25XENWKpUeTCIdKMoclFIM13B0lL7T+3ie98JsNvt9G9lukeErJOZ2ICIO1EUAwF8zVtMurabomBvnzZu3b5Rax8grnlLqA0KIfzGdEQB8LwxD5vR+JJVKPVwsFnnVeggRHzXV1c7+Drj5sZxutnOuLmMppXYLw7AcpMVikUuaOHWO731nexf9G5exekF206ZNqZGREX7tadpMAo8ryZsiJzUY6VeIeEgrQ7rt9+vXrz90amrql5Z2xXK6aTl214pxPSavoLx68vdKgJZX1cphUW1VFUL03FYXALZJKYeiPIDIgedQGNizH0KllMtJ7rGI+OMoD6HfZ2cPTExMzJucnKwF6CxBWg1UPjxySk6P2fd/RMTnRNEZOfAKhcKrwzC8LYrSaX1CRExZyHVcJAiCywDgGhtD2n26aWPjXJBhwOUdO3Ysqr6PciByoHqeV11JyytrZUVNOgGkJVlJ1ecmgfeiMAyt7qc2bdqU6UVYgHw+f7jneT+3/ID27EpvOd+uFtuwYcPA5s2beSu7XzqdrgVlgyDld9WMxYS+hogviyIXOfC01odxMWkUpdP7hGG4qFOnkzb21su4sMOmUqkjhoeHrXzmandf3t4DtgkUUchKjFe8CpQe353ZtJ4iL5kWeO8QQtiSjaxBxDfbOKwv0zkP2BYlRyErMQ68ygvvUzbu6GV6qrGxsSNTqdTPbOYthOhvNy0d10kxpRR/zueZ2kBEV/u+H+nKLfJWk41QSnEt226mBoVh+KpcLtez0BG2SNrsp1Kp9PyVK1f+2tRn/f6d84At/k0UshLjFa8SePdXsC+NvEJEF/q+37NgSUqpdwohrjaadKUzAHxISnmpjWxfpv0ecKSlG/Z9f10Uq01XPN5yHRlF8bQ+b0XEnoUHdMHR7283LT4tHRRRSj1fCPG/NiYAwNlSys9GkTUKvCAI7mRChiiKp/V5HyIaA+JajJOYiNb6LiI6wWYAV+g/mzH7MnYeCILgxQDwLRvpKGQltlvNW4UQNUj2qMbNhctkl9xNIcRViMjcDP3W5R4IguAcAODcYuPmed5R2Wy2KVmJbeAVhBDDxhYJ8UlEfL2FXNeI5PP5YzzPs00B659uds2TbG5IEAQrAcCK0zEKWYlt4PF9Ft9rmbbIN/qmitvZXyn1PSHEiTZjMkFLLpdjHMd+62IPKKWsMW9aodjVT9v0Hc82d/HHiNjzYK0ulelCCCZ+qdYflmsPU6nUI82IVLr48zlnTVNKMYPvaosJRiIrsVrxtNZMmKhNjQKAP0kpexUoqTZdpRRjznDFQpyNoSk4IDdXC4M5KMMwLAcp/8xfk5OTD1100UV9Msk4PT+LLq31jUS01HQY5hb0fZ/ZeyM1oxXPgcrqL4jImeGRcOsjWd6hTi7bzRhM5gSGnVbNCiTGZg7USpA+NDU19WA/SO287cDaFImsxGrFU0qdIoT4hs2Upqam9u3Eh2Ht2rX7eJ63LwDsm06nnwjDkFeWRxHRCqBXa/1uImoJWGrjo5hlnq4L0hmrKQCUgaH6Qbqz15VS3xFC/KPFs/guIr4oqpzRiudykRwVBKaZ4Uophg7Yd/oXAOwz/f+IaGHl/2aoJKL7AeBaRFwb1VHVfkEQHAcADYlPTPV1Q38iKlbwbmaspqVS6WHP88rAUrtCkCqlGHXgUIvnEomsxGrFW79+/TOnpqbuszCKRXaCPbvpppt2n5ycZCiAfUul0kLP8xaGYbgQABZy0PB3XqWqPxNR7NB0AHBHOp32ly9f/geTOSmlmDnphSYyc6UvAFD1kIiINlcDllfQUqnE7K89HaS2lQlCiEhkJVaBx8Hy1FNP/cXyQ8SrBK9C/NVN6MjfFUKcYYK/qbW+goiutPTDLiVGRI9NW00fZmjGbgzSCkcIw0kaVyYIIT6KiG+N+nCNtpqsVCm1QwgxEHWAHul3KyKeE9XWfD5/vOd5DJrbbzF6gMGC6q5cGPKxjJ/ariB1rDmNRFZiteKxUBAE7AwGmZkzDQAmM5nMIhPObaUU42a+YM44ofcm8hcOUgDgAC1vb12D1BFZ7mKTMwObFc/25bPbH+1ZiBgZzMklw6HbHTEH7ePC1vIK2ixI582b9/xSqcSvHjYtElmJ9YrncNxqM5l2yrwLEa+KOuDNN9+81/bt2++yPAGLOky/X494ICpZiUvgfU4IcWaP+COymQAgpZScBB65Vei0bo4s0O84lz0QiazEOvCCIJgAgDfNNQ8S0Wt83+c/KkYtCILLASDySmmkvN+5Zzxgek9t/I6ntf4wEbXkeO4Zj/2VyfXXAPCPtnwOzGHneR4fJXORcNKgqb3k2l3J1oUmnx/jwFNKXSSEuGEueRQAVkgp18cxp0KhcCwRPatCecXAqHwCzN/rfzYGjIrDtr6O5DwQlazEeqvpeOSa3MztNX8CEc+zFzeXXLNmzV4DAwOLKkSSNQosDs4KZ12VaYeDtefIO8w90vMSjyOiUWaV8YrHLnLIZ+s2D1+JiFz42LVtYmJiweTkJBNIlgO1wrSz0/e61TTdtROZ24ZFJiuxXvFYUGvtE1G+R33JVwC3A8BdUsqv9ugcZjX7xhtv3GfHjh21IOWArAbqtK0ub3+t/ujOJX/FNRcAuFtKeZyJPmvnK6X4PY/f9zrZtgghuDj0UQB4jPMC638mokc9z3usVCo9Nm/evEcnJycfsy0H6uQkkxibGV/ryCNr759V5tfqtrfLaLCScEUcOj+FiEY05daBV9lyjgAAV6Uf4Gg9M2hy0MwIIv4/AHg0DEP+Xv59JpN57L777nssCvOmo127vDgRgdZ6p61u/epZ/05aKc/aFX22BBGNkMmcAq8SfFzujkR0JAAw2C2f6JWDpT6YKv9XCyz+Pa9E6XT6sT7uyNz4rHJ2/6JFi8oHQ5z7Wj3ZrX6ftu2NxJzaA565FxGfbWqnc+CZDtjv3/cAe2DNmjWDg4ODtQOj6YdG1VWV/7/L70aziDhu+lT7gWfqsX7/tntgw4YN8x9//PHyfSif7E47KKq/H+XftbPW88OI+HYbh/QDz8ZrfZmu9cDo6OgenLTAB0e8WnqeVw7UWe5HOWDnO0yEoUMus5XvB56t5/pyPe8BxvCZ7X50eqBWTn+5Mp3r/v4YhuG1uVyOwY2t2/8Hr+rCOm3min8AAAAASUVORK5CYII=";
  }
}
}else{
for (let i = 0; i < pictures.length; i++) { 
    if(pictures[i] == null || pictures[i] == "" || pictures[i] == undefined){
      const imgs = document.getElementsByClassName("img" + i);
    for (let i1 = 0; i1 < imgs.length; i1++) {
      imgs[i1].src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAN4AAADICAYAAACH6F8xAAAAAXNSR0IArs4c6QAAIABJREFUeF7tfQuYXEWVf53b3TMJr80AIQTURf+LyhsWFhFWEcGVVURBiCIYTDJd53YCUVFEVsVhVUBQ0ZCZvlU9ySwsshpF8bkKKj4XXcXHqqxvEQIBAkkQA2Sm+57/d9ru3s7MdPetqnv7Men6vvlmkqlz6tS5fabqVp3z+4Ho0bZhw4aBzZs3751KpfZOp9NDxWJxbwDYWwjBX0P8nf8dhmH5OwAMEVH19/cCwL1E9HkAuFNK+dMedYMYHx//OyHEomKxuHVwcHDLE088sXX16tU7enU+u4rd0OmJjo6O7pFOp/cmoqFKgJSDgwPG87xyANUFTC2ohBB7xGT7tjAMz8rlct+MSV/iaoIgWAEAq4QQzxNC7DbLgE8KIbYIIbY2+k5EWwBgK3/xz6lUauvw8DDL9FsbPBBb4I2Pj++9Y8eOvTOZTDlYqitN/QpUDaLKylTuJ4QYaMM8Ww6RyWQOW758+T0tO3a4g1LqI0KItyZoRsNg5SDmQC2VSltTqdQWXmUzmcyWbdu2bb300ku3J2jTnFPdMPC01keHYfhMg+1brzvnHs/zXp7NZjd260SUUtSttgkheHtbDtrqKsrfwzDc6nnelvrvHLRTU1Nb582bt+W+++7bOjIyUuzieSVi2k6Bp5R6ARGtBICXCiGekciI3a30ekS8pBtNVEr9UAhxXDfaFoNNf64EbXnbW9kCbyEi3gqXv3Pw8kqbTqfLQbvnnntuueCCC1iuJ1st8LTW5xNRXgixZ0/OJCajETG27XdMJgmtdZ6I/Lj0zSE9pWbvsdX32+nvswMDA1uXLVv2dCf9UP6QKaVyQoixThrSLWN3W+AppYaFEIVu8c8csoMPoJodPtVW2erWmE+Nh4eHWcZ5yw9jY2NDqVTqrsoJ2Rzyq9VUnkbE+VaSCQjxezYR/SQB1X2Vbh7gLXF5G9zsfZa3xo1Oy0EpNSKEeK+bHXNG+h5EPKxbZqOU4kOHVLfY07fDygNPCCG+AgBfkFL+e1UDBEFwMwCcb6Vy7glNIOLybpiW1voeIjqkG2zp2xCbB65FxMtYG694PxNCHBmb6h5WRESn+b7/9U5PQSl1qxDi7E7b0R8/EQ9o5IOELr8bSmTmDZTejIhvbOeAs42ltb6ciK7qtB398ZPzgOd5x3HgPVbJIElupO7X/KjneS/OZrP/20lTlVL/JIT4aidt6I/dFg9oDrzfCiE40XZXbpcg4vWddACn3JVKpQeFEIOdtKM/dls88BPQWv+AiI5vy3BdOAgAfFVKeXqnTQuC4OcAcHin7eiPn7wHiOghXvH+UwjR8Q/etOk+JYTYVve1mYg2CyEeAQD+2hyGIX/ndyHrNCoi4uP6U33f/3by7m48QhAEnwGAs1xtAIA7iOhDdfm1O1V28P9Pq/TIuI7Zl7fzAAfex4UQb7ATbyrF2erl4AEALr15nL8TUfnf/P9hGG7mQOKAKhaLmycnJx+55JJLOOhatiAIrgKAy1t2bNKBiK72ff9fXHS4ymqtryGi8hGzSyOi+wcGBk5avnz5/VH1cE3j448/PhSGYbkkq1QqcX1jtWqkVdBGHabfb6YHtnDg3SCEuMjUOwDwvTAMb6sGk+d5HEgcVFt37NixefXq1YklsBYKhZeEYXiHECJtandd/7vnz59/8tKlSztWzlLJj73ZYQ41USL6J9/32SdtaUqpv0mlUgsqQbuA6ymrBciz1FBWC5D5+y6dC1x5OL/nd7wriegKi6f1K0TsyAVvEARfAoBXWNhcEwGAc6SUfF/WkaaUej4A/IiIdo/BgIsRcW0MehJXsWbNmkFeVdPp9ALP88oBCwDl70S0YBpSQH3A8s/zEjewPQP8kFe8twghbE70NiPifu2x8/9G0Vq/mYg+6jjuOCJmHXU4iSulOAfzaCclfxVei4gXx6Cn61Vcf/31C+bNm7eAV9Zq0PJ3IUT5/zhwq4FcuSKrD9xuSr27nVPGlgLAjRZeDxGxrZMJguBQz/P4AOEAC3urIr8Lw/BluVzuXgcdTqJKqQ1CiHOdlPxV+HZEfHkMeua0iomJCV4pFzz55JNcEFAOUl5lK1vj2r+nBW5168y/j7t9AvL5/Bme533BRnO7S2iUUuuFEMtsbK3KEFHO9/3ARYeLrFLqA0KIOA50fpPJZE4zOUxxsXtXlZ2YmFhQLBbLgTo1NVULWP43n0QT0UkWvsnzO96JRPQ9C2HBp2ArV67k+qTEWxAE5wHALY4D3YqI5zjqsBbP5/Nv8jxvwlpBRRAAJsMwPKOdhymuNs9FeaUUZzo932JuH+B3PBa0SpVKpVIHDw8P/85iYCMRpdS+QoivCSGOMhLcuTNfXbxSSskQCm1vlT9wfGe6VwyD98xhSgxz7VoVWutHiGihqYEA8Dbeau7ned7DpsKV/icg4g8sZSOLxXTXdQUivi/yoDF2VEoxBB9f0h/rqpaIPub7Ph+I9VuHPaCUYugJz9QMIloOIyMj6cWLF0+ZCnN/Inql7/tftpGNKhMEwakAwKudS/va0NDQ6UuWLGFHtb1prW8hovNcByaiz/m+/xpXPX35eDxgW9njed5rqpgrj9tsgQBgaX1VbTzT2VmL1vp2InqZg+5Jz/POymazif6BaGSfwz3pdJU/y2Qyr+ofpjh8EmIUrSS1c2WPcSOik6uB90chxEHGGoR4KyK63qk1HDYIgksA4MMWdtVEiOgjvu+/zUWHrWwQBBcAQK3c31aPEOJxIjq3f5ji4MGYRYMgOBgAfmOjNgzDI6qBd7cQ4u9NlQDA+6WU7zGVi9J/fHz88FKpxLDq+0Tp36DPD4vF4pmrVq16yEGHlShjlAoheJXlS1zXxkXL2lVJXz4+DxQKhRPCMGSQMOMWhuEzqoHHOX6nGWsQIo+IKy3kWorEgQVDRBf6vn9Ty8ES6KCU4vfSU11VA8DVUso47v1cTenL13nA5f57+/btu5UDT2v9SSJaYupZItrg+/7rTOVa9Y9ji0ZE63zfZ0zKtjelFG9tPxTDwJ9AROdDmRjs6KuY5gGl1IVCiH+zcMxTiFgLPFuk4q8jos1K2dDeyvUGbzFdErB5730OIv7cwjHOIkqp7wsheKtp3Yjo+6VSacmqVasil/lYD9YXNPaAw/nDg4h4YHWraZvG9FNEPMbY6iYCcbDhENFq3/e53KkjTSnFweLCPfGQ53lLstnsdzoygf6gLT3gkPr3C0SsHa7Ybo3uR8RntbQyYoc4wH6I6NO+78eRgBzR6pndbO93qpqI6OO+719gbUBfMHEPKKU43xdNByKi7/i+/+LqO95yficyVSKEeBIR46gnKw+tlOIt5skWdlRFHuZ31U5DOSil/ksI8UKHeXByQseuQVzs3lVklVKfFkK81nS+APA5KWXtAp2zIT5rqoT7x1WhoJR6pxDiahsb6laK9/i+/34XHXHIBkEwCgBxnPa+AxGvi8Omvo54PRAEwZ0A8BJTrUT0b77vLyuveEEQvBgAvmWqhPun0+m9VqxYwfjw1o3JOTiXkYisYQEqQD/nIiJn4XS0xZTmVp5DJ69EOurELh9cKfU/QogjTM0EgI9IKd9WDrx8Pn+453lWJ4CZTOZZrmlMSqlrhRCXmk6irv8OAFgipfy8g45YRZVSfJ0QR8YM/yFZgoi3x2pgX5mTB5RSzBx8oIWSdyPiB8qBd8MNNxwwMDDwgIUS/ot8tO/7zL9g1a677rrd99prr79YCVeEGNLO932XwHUZflZZRvDatm3b54kojgrx31TeXa39HPsEd3GFSikGyeKqE6MGAKuklGPlwOPS+MnJyUiwetNH8Tzv1Gw2+w2j0es65/P5l3ied6etPMsBwDcGBweXXHjhhVZJqy5jN5Ndu3bt32YyGV6F4yCF+XYYhufmcjmGQ+y3DnvA9uQaAM6TUn6iRjtsG8GVbdCnbP0QR+BVxn6gst3kE8WuaZWcTQ6+OIChPoWIxhlGXeOMOWLIunXr9iwWi1bwlWEYnp7L5b5aH3hWl74AkJNSWmOYxBh45ccKAMuklDapPIl9LJRS1qfG040CgBuklKsTM7avuKUH8vn8QZ7ncUWPcQOA4xkFoT7wbHnyyi+LxhZUBEZGRgYWL17MBwhxYiZeg4hOKNO282kkFwSBDwD5mPQ6+TwmG3ZZNYVC4dgwDH9k44BisXjwqlWrflcLPK31nURkfC/BmJyIeImNEVWZIAhu5KJaFx3TZYnos4ODg29YtmzZ03HqddEVJ+2153nD2WzWJunBZQp92b8meljTqaVSqX2Gh4e31K94ViykAHCTlJIzta1bBQiIeeH2sFYyu+AvK6eB98Ss11qdUkoJIaS1gv8TfCoMwyW5XO6LMejqmApePUql0pEA8CwA2IuJZJiURgjx+1Kp9JNO4p82ckqhUDgvDEMrxLtqwkl94BWEEDZlNF9CxDNcn1zc73p19hQrH1CrzBzXec2yEjOk4m1CiDNj0P1Hz/POzWazXMjcM01r/Q9CCE5T5JSrVihd/MfzVgBYh4j3dcMkgyC4GADWWNiyFRHLhdH1gfdBIcQ7TJUBwPellE55idUxtdaHEdEvTG2I0h8A3iml5Dl2vCmlFgshPieE4A+gU+PyoUwm89oVK1YwqWVXN6UUJ9TzeYBtAvj1Q0ND71qyZInV1VdcznF4Zfg9IpZJYOvf8S4jomssjPstIj7XQq6hiANQaCszJhBxeatO7fh9Pp8/xvM8Dr5nxjDebVLKswGAYtCViIoKIDGffrviiv7B8zw/m822jRlpukNsGbaEED9CxPIf2/rAyxKRDa7HFkR0wUWZ9UErpfhKwOndcTbFTC9WKpUu6IZ3hyAImBD0CwDgQjdWnaZCRD+RqHFUqrV+OxHFmuwNACuklAzp3/bmANdY47qoBV4QBOcAgNVFeFwVCrP8ZckJIcYS8OyjRPR63/e/noBuI5VBECwDgLg+QFci4oiRAQl3jhEGY4alnbqzVUrxQSCfbJq2GpRHLfDy+fxLPc+z+iAODQ3tltS+e3x8/JhSqfRj0xlG6d9pApOqjVrry4mIaaWdm2tCg7MBdQq01kuI6JNx6pyui4hOa/cfUKUU3+HZoILXwMHqt5pHExFzthm3dDp9YJIv90xmODg4yPwOzzY2rrWA8z1k6yFa99BaryGiOHjuip7nnZPNZvn9sWMtn88fWKl4YbqrJNvvt2/ffkRUCu84DFFKMV/I/7PQ9QFEfDfL1Z9q8onTnyyUcZrW4VLKX9rImsg47K2bDgMAXwaA5dls1pZDwmQaDfvGyJv3QCqVOnt4ePi/YzHMQonW+kYiijUpopEZAPAxKWXb+CSUUo9a4r2+HRHLAM21wBsdHd0jnU7bFrS+CBG/a/F8jEViYoSdMS4AMGHlUt/3rUBKjScyi8CaNWsWDg4OfkYI8Y+u+gDg7nQ6fZZrraSNHfl8/njP8xIns5lm2yGI+Csbe01lXMhKfN8v07TVAo//oZTaIYQYMDWEiM70fd+K3NJ0LO4fBMELASCRKgQAuEBK+XEbu+KQqSBo82V/+b7HpfFKfvDBB7/6lFNOKbroMZXVWo8T0QpTOZf+7WJRqrz22KYhnoWInDwxI/A2CSH2N3VAJ06XKqsDv5PaVAG3muIIIl7ZqlNSv9dan0ZE/IDiAJJaj4htC4INGzaktmzZ8gQAzE/KPw30bkbEOEqvmpq9bt26A4rFom3R+MlVIK7pKx6/px1q4bDa3tVC1klEa/3pSuqRk55ZhG9Jp9O+K56MrVFa6/OJ6GZb+WlyVyHiu2LS1VRNoVB4RRiGX2rHWNPHYPAhKaUVdlBUe8fGxo5MpVJWSACpVOqI4eHhcmbW9MBjAFXj94tO4/srpRj2gXFb4m5385bJBdrCxaCY78DawiKrlGKUt7YE+Sy+vRwRbbKvIj8mpdQpQggrxAUmK8nlcuXVcnrg8RG0TfKuZjqbyNYn0NGlVKOFOU8Q0Zt83+dDj7a3IAiuA4C3xzEwAJwjpeQqlMSaUsr2MxSHTTcj4hvjUNRIh0uiSf19906Bp7We4A+ZheG3IuI5FnKxioyNjT0nlUoxb0GrjHfjcQHgUillHEQkxmMrpZhjzzaxuH68RwDgLCllIgdTPJBS6qeOXPXG/qkKAMA3pZS8IiXWlFK8wNggLjyNiLX33umB92EiMi5qbceETTwZBAHnPzqXKs0yZn5oaOjidlM6T0xMLJicnGTkYmfaLyHEzz3Pe3U2m7WCLmj1HLTWDxDRAa36JfT7nyEiY7Qm1pRSTJlmjLgAAA9KKWsHgdO3mrw3t0Fi/jkixoGkFZvDgiB4NwC8LzaF/6fo64wSLaW0YgO1tUcp9XwhBAffYbY66laGOzKZzJlJVOcHQbAJAIxPxl3nxPKceeX7vjHBqsnYDqQ6v0TEw2vPoH5QpZRVUvL0aDaZSJJ9tdavZRKTBMbYSERZ3/e/koDuhiq11icTEb9rOrPMxoEcMJuhSinbk/E4XBk7bdx0o2xhSqpkJbMGntb69UT0HxYe2IGIcYIVWZgwu0gQBEdV4On/JjalFUVVcNK49TbTFwTB6wDgE3GMCQAflFIyZ0VsTWv9lZhAfI1tAoB/k1IuMxY0ELB9jamSlTRa8axBXIaGhgaXLFkyaTCHtnWtoFXzSmFTytHUzk6w+gRB8GYA+GgcDgSAt0gpPxaHLtbhsBWLw4TLEDGJa6WabUopqyu3KlnJrIEXBMFxAPBDGw94nrd/p5OMW9ldKBTeH4ZhEndMt3med3E2m2U8/bY0rfVVRBQLhCEAvE5KuSEOw+NckU3taccFulKKL8CN37OrZCWzBl7lOP73phOu9G9bkqqlfWUxrfWbiKicqBpz+wURrWonN59Sigto49habSOiV8dh+9q1a/fJZDKcvd/uVgMSSnJgW7ISItqJQm6nU83rr79+wW677bbVxnAiOrGTmf0mNiulODuHMTvifi+dIiKsZqCb2GTTt1JRwivVP9vIT5P5VSXZ/beuuoIguA0AXu2qx1C+LdAXtlQH088Ddgo8nqhtyQMAvEJK+Z+GzupY99HR0f0zmcx/WIL4NrUbAN4vpXxPOyanlOKCTA6+OI7R7ywWi2euWrXKib0pn8+f4Xle26pV2M9VaPQkfT4yMuItXry4ZDMGEb3B9/3aweVsgcdgovtaKD8fEa1APi3Gik0kCII1ABBH5fd0m25JpVIXM2pwbMY2UJTP50/yPI/xchg20LXdgojnuypRSvGO4jRXPRHlY7G51Vjr169fODU1ZcXWBACnSykZq6XcZgu8XwshbOD6LkLE0VbGd+PvtdYXE5ENQGmr6fyAg5pJKlp1dP19EARne57HlRoznqmF7g8jolN+aIUlidP3km5Pl0qlw1auXPmHpAeqJDEwBIlxm74iz3hIQRDcBQAnmGoGgPdKKf/VVK5b+mut/5mIGA7di9mmzYyl4vt+oqA/bLPWeiURxfLHL46CYKUUAyQnCiLcTpi/8fHxk0qlkhXSQiqVOnh4eJixWmZf8bTWXyKiV1h8+NYg4pst5LpGJAiCgwHgRiFELMjY9RMDgH+RUl6d9GSVUvzHL473y3tSqdSLXLfKQRDkASApvM+21RnycwuC4NUAUK4gN21VspKGgWebCQ8AH5dSxpFBbzqnuPtDEATrAcCmSqOpLUS0bnJyctXq1asZYiOxFhcxShiGy3K5nDPXoFLKlpejmY+uQ0RjygEXp2utme/BiqEJEXknVUP6nu0dj7MYbIgPv4KIcRxru/gmNlmllG3CeFMbuJKjWCyuSPKdpIILwiedNrWV9fbHtovRWl9JRFfE8YAA4G1Syo/EoctEh0PB9Yw7xtkC771CCBs04h8i4vEmE+n2vkkBsgLArVLKROsXmX89nU5v4Jd6Wz/HXe4VBMErAICBe4+ysYnh94none1CtJtuo9b6GiK6zNR2IvqD7/s74XDOCDyHE74/IKINyKfpPNraXynF92OcIWL1YWlkbNL3Tvl8fj/P83jVO9nBYYkc0+fz+azneQzA9IKItn0rDMNCLpfrGPob26m11lyVEtHm+m41spKG73gOIDuPI+ICC6O6XmTNmjV7DQ4OcvAxn1tcLVF8kJgONRKltK4cz/MfBv6jxsSU5c8PEW0BgHuFED8tFovfTHJbbvIwgyD4FMNnmMhU+tbIShoGXmU7YIUSNTQ0lG53dbaFE6xFgiC4BgCMtxoNBvw8IiaSVuWwa6k3dXsqlTqhiopl7bQ5JOiQFPBJRHx9vStmbDXHxsZOSKVStmjKCxGxEwmybXu8SilmzeVTOtdWY45xVVQvX8Hk5OJf1/rDth7Vx+mDpHTFQVbSbKv5XCLi7BXjNv2S0FhBjwhUKsF56/kcB5Nj38ZViEL4ve5EB7tY9Lvz588/fenSpdsd9cwpcQeykhl/xGY71eQ8Tc7XNG5JHxgYG5SgQOVDzsFnVVwLAOdJKWOpJK9OMybo9G1CiNMRsd3cBwk+rXhUx0FW0nDFc8nAFkK8HBFvj2ea3a/FpeizWCwevGrVqloKkets4wK/bWcKluuc2y3vULkzg7121oRapRTX5BmfUFZYVhPPSWy3wxuNp5RaK4RYZWFPrEWblTzTL1vYMV2kK7gCY5hH7CpcalWFEDWykoYrHv9CKcVV6MbvL93CsBq71xsoVEoxhr4xrCEA3CGltNqiTjcln88fVLmvK5PaO7TbpZSnA0AtrclB15wTrdQ9Wu1QiKhGVtIq8LiM5TgL7yV6N2VhT6IiSimrDykRXe37PgOjOreYCCAfTKVSL+9fHTR+HI6cf0ci4s/rtTfaatqSq1+LiHHdczl/KJNUoJQ6QgjxPzZjAMDZUkrmwHNqSimG5nOueEjioMdpYl0o7LKdrycrabXicYn6Thd+UXwBAOuklHzPNeebS+1bsVh81qpVq+53cZJLicq0cWu83C72zHVZrfUbiegmy3nujohPtlzxtNajRLTSYpDbEPEsC7meE1FKWf1xEkJsRMRnuky4UjfIhymurLG7zPNy8TfLKqWYY/16Cz07kZU0XfG01u8jonebDgIA35FSvthUrhf7O8C8fdH3/Ve5zFlrfQsRneeiQwjxu0wm8/Lly5cnDpngaGdXiNsWGDeiN2j0jvdWIYRNvdM9iGgM9tkVnjUwYmRkJL148eIpA5H6rk40z0opri53hthg+D0p5ect57DLiWmt1zCEh8XEdyIrabriKaUuFELYVB4/jIgdYYqxcIi1iAsrqOd5r8xms1Z3bi6kiNMm+y5E5Lq4fovoAaUUv98Zk1422gXOuuIFQfAqALD5a1hExEzEufRstyAIrgCAK20mEIbholwuZwwRt379+kOnpqa+LYTYx2bcOplEauwcbep6cVuyEiHErFUojbaajLTM5AzGbWBgYGjZsmWc7zdnm0N5yK8RkXnujBpD9hUKhS9aglDVxiKiXwwODr5s2bJlDxkZ0O/MhytWZCWNGIwarXiHAgDznBk3z/OekxTbqLExCQkopZ4QQuxhof5TiLjEVM72xX76OADwMinl10zH7/cvn2pakZXwSSgizmBZnjXwGN48nU5vsnT4sYj4Y0vZrhcrFAqLwjC0XTGMM3uCIDgPAOJA6H4rIsZC7dX1DykBAx1OsXciK6maNmvgjYyMDCxevNgKgo6ITvN9/+sJzL0rVBYKhXPCMGS4dONm6hut9dFEdHcMILvjiGiDFWI8x7kqYEtWIoSYFWG9Idy37XaKiM71fT8J+uOueKZKKVv4Qya72AcRH48ykQ0bNgxs3br1mzGA6/5w9913P+2CCy74c5Rx+31mekAptZsQwqooeDpZSdMVj3+plPoTA9BYPIgsIo5byPWEiNb6R0R0rIWxP0bEyHJKKc6S4GwJpwYAJ0kp/8tJyS4urJTiOOB4MG7TyUqiBN5PhBBHG48kxDsQ8ToLuZ4Qsa1IMOHnDoJgaQVK3sknACCllHHgwzjZ0evC+Xz+GM/zrM4twjB8QS6X++/pPmi41QyC4OsA8FJTp8VZ8mI6dtL9tdaH8ZG85TiXIGLLXD+t9T8Q0YwHZTFmbCjQFmPPKZEKgBTTjhm3RjhEDQNPa/0pIjLGECSiwPf9nLGFPSAQBIEPAHlLU1/UCgG5wvDKtZDGd331NhHRd573vOe99JRTTila2toXq/OAC8TH1NTUvhdddNFjkVc8B+KLRGDruuGToJRiJOM3mNpCRH8eHBxctGzZsqebySqlOE2P0/WcGgAcI6X8qZOSvnDNA0opXkjGbFwipfRmq+pvdqrJBZZcaGnavoaILzMV6oX+DvBu30XEF7UIOuuHW683Dl67XngW7bRRa305Ednktm5DxKHZbG0WeJcKIa61mKDR6Z2F/o6IcNqW1jq0GZyIxnzfbwiKpLU+kYi+Z6N7mkzsWJ0x2NTzKpRSHAccD6atIZ9Iw8ArFAorwjA0vhYAgD9JKQ8ytbDb+wdB8GIA+JalnYiIejbZsbGxoVQqxfS+iyx1l8WI6A7f92MBUHKxYy7KxklWUvVPs8OVs4joMxaO3I6INnmMFkO1T8SFL68Z0K9S6nMx8Ng9DQBHSSl/0z6P7Doj2ZKVNEOTaxZ4JxMRZ04Yt3Q6vdeKFSs4kXjONAeK6k1SygNne8FWSjHS2AdcnRQXeJKrHXNV3qEaZQZZScsVb2xs7MhUKsW4kTbtbxHxPhvBbpVRSjGsPcPbGzUi+qrv+6dPFwqC4FQAiKNS4ApEfJ+RUf3ORh6wJStpdrXW7B3vGWEYWiFhEdHRvu/bBq2RU9rRef369QunpqaMi1crts3g6mbSyFQqdT8RDTjanxjVl6Ndc0rc4TS7IeNSs1NN68TQMAxPyeVyVtvUbnxiQRCczfTJNrYR0Rt937+5XlZr/W0ianq9EGGsbZ7nHZHNZjdG6Nvv4uCBOMlKWm41uYNS6ikhxDwLm2dgxVvo6BoRpRT6PUFVAAAUpUlEQVQDPzEAlE3bCUU4CILrAODtNorqZRol37rq7cvv7AGlFEOZcOKDZ+qbZgQwDVe8SuA9IIQ4wHRAIlru+/6EqVy39tdaf5eITrKw73eIeHBVLkaworcj4oct7OmLGHpgYmJi/8nJSdui8IYLUKvAY7z3ww1t5Tult/m+bwMPaDpUW/orpSaFEDYgTp9BxDJv+ujo6DPT6bTzgRMAbJBSvq4tE+8PIlwS4wHgJVLKWe9+WwUeCxkD1BLR+33fZ/zHnm+jo6OHpNPpeywnUsPQVEpZ/RGbNu5DqVTqsOHh4S2W9vTFDD1QYf+1Pa+YQVZSHb5V4DGxxmsMbeXuaxHRBvzTYqhkRZRSkl93bUYJw/DsXC732ZiYWoXneS/OZrNW6G829vdlyucc/Pm3IpjxPO+ZjQ6/WgXeOiHEctMHAAAfl1JeYCrXjf2VUrY+ICI6mGsaiWjWdDHD+a5ERNuSJMOh+t2rHgiCYBkAMOW2TZtBVhJpxbM9gQOAL0spX2ljabfJOGwRf1YqlZY6JCHUXAEAN0kpncuFus23vWCPUsqWzmAHIja8EWi64jmUQ9yFiCf2gmNb2WgL9SCE+HchBFfwH9hqjBa/v3dgYOCQVrV8jmP0xRt4wAHTdBMiNrwRaLXVRCFEYPFUfoOIz7OQ6yoRpZQ1orYQghPMz3adkOd5x2WzWYb467cOeCBuspJIW02l1LlCiA2m8yWix3zfN85rNB0n6f5BEFwGANckPU4T/W9CxBs7OP4uP7QtWYkQomnxc9MVzzGRt+GLZa88TaUUp4k5r1qW89VcxGcp2xeLyQNxk5VEWvHGx8ePKZVKtrBmz8jlcpz50rNNKcVJ4s9o9wQA4H+llIe2e9z+eDM9YEtWIoS4ERHf1MinTVe8fD5/kOd5f7R5IABwuJTSivjEZry4ZdauXbtPJpN5NG69UfR5nndoNpvlqvR+67AH4iYribTirVmzZq/BwcFIkOOz+KclnF2Hfdp0eJeLU8d5LUFEK24Gx3H74rN4wJasBADeI6V8v9WKx0JBEEwBQNr0qRDRmb7vf8FUrlv6B0FwFQBc3k57AOBjUkpn2PZ22jzXx4qbrCTSisedlFIPCyH2M3UwEV3o+z7T1/ZkU0pxdfipbTT+J4j4920crz9UCw+4vG54nveGbDb7H9YrnlKK3zWMkY2J6C2+7zOzTk82pRSz6+zZLuNTqdRBw8PDVsQY7bJxVxtHa/1cIvq1zbyJ6J993/+KS+Ax3qNNFkotM9/G8E7KuDjc0u4zEPFLlrJ9sYQ8MDY2dkIqlbrLRn0jspLIW03be4xefl9RSnFeJMOpJ94A4INSShvE7sRt29UHCILgdAD4Txs/ENFzfd//rfWKp7W+kYiWmg7ey4m9WutRIlppOmeL/nMmp9Vi7l0vorV+PRE1fE9rNoFGZCWRVzwHgsQvIOKZXe/dWQxUSjFjz3FJ257JZPZbvnw5wwb2Wxd6IAmyEpPA40ryfzX1CwB8R0ppXL1uOk4S/R0qEiKb43neqdls9huRBfod2+4Bh+qchmQlJoHHZBtrLWb9C0Q8wkKuoyKFQuGEMAytXqgNDL8SEUcM+ve7dsADSZCVRA68QqFwXhiGt1jM+wFEbHueo4WdO4kopVYLIRK7BgGAb0gp23k/6OqSXVbegazkbkRs+qrSNFeTPa61fjkRNbyPaPJUnt6xY8eC1atX7+ilJ6e1vpmIzk/I5uL8+fMXLF26dHtC+vtqY/RAEmQlkVc8F05uz/P2z2aznPnSM00pxUfAf5eEwQBwkpTyv5LQ3dcZvwdsyUqIaIPv+00hGFuueKOjo3+XTqcb3ke0mO4hiPir+F2SjMaJiYkFk5OTW5PQDgDvlFJ+MAndfZ3JeMCWrAQAAiklM/w2bC0Db3x8fO9SqTSDPD3KVInoRN/3kz6oiGJKpD4uF6ZNnTyHwJ8iOXKOdEqCrCTyVpM72h6vE9Erfd//cq88hyAIrgCAK2O29y9Syr1m48eLeZy+upg9YEtWAgCXSik/5LTiVQKPV7y9TecVhuEFuVzu46ZyneqvlPqiECJWWMJUKvX3w8PDP+nUnPrj2nmgUovKrx2xkpWYrni2Bw4XIeKo3dTbL6WUYg68hXGNDABvkVImdjURl519PTM9MD4+/relUuleG99UEcSdVzyt9Q+I6HhTI4joPb7vN6zCNdWXZP9CofDsMAz/EOMYNcISU51KqcVCCAY6YiZZ/nl/IQRTWz8khGDmGv4q/wwAm0ql0kNEtGlwcPDBuUaBbeq7uPoHQXAUAPzURl8zshLTFY8ztGfQCbcyCgA+IqV8W6t+tr+vfEAXA8ABRMTgofz1IBE9mkql/mSCRxkEwesA4BO2ttTLAcBmKaVx8XBlWz8CANnKfGzMebIanET0kOd55UANw7AWtPPnz9944YUXWh2Y2RjUizL5fP4lnufdaWN7qVQ6auXKlf/jvOIppfg97Q0WRkwgojH3QoWq+IAwDA9IpVKL+XtdcDEyM3/xKtCqac/zdJQAVEq9SwgRy+psC1bkkg3fyhGz/D6srpy8WnKAcqBWgxYAHiCijYhoyw1nYVL3iLhg7jQjKzFd8W4QQlxk6hYA+KyUsoZLqZTa1/O8A0ql0jM8zzswDMPadwDgYOIUswWm40TofwIi/qBZP6WULWr2dLU+IhqzCxUKhSPDMLxdCLEownza3YVXxxnbXCLi3cXGTCazcePGjQ+MjIwU221YUuMlRVZiFHha6yuJ6ArTSQLAN4mIg4mDar6pfIz9706lUv/UjFdOa/1aIvq045i3IKJVupkDOYajybGKz9jmhmHIq+lGDtC6VZT7dXVzeB5NyUpMA+/NRPTRrvZUC+OI6GO+7zdE8HLZ01eGvh8Rn2XrI9tKf9vxOiw32za3vLXlIC2VSg/Mmzdv47Jly7Z1ys6kyEpMA++NRNSziGE8WSL6he/7DcuUXHFWPM97TjabtQL/ZftskxQ69cFs47j121xGJuev2uoZhuHGXC7H10CxNgeyknsQ8bBWxrRMGat8KPhSmS+Xe7qFYfjsXC43693MunXr9iwWi4wsZtM2I6LVKWZ1MK01/8VvSOtkY9QuJlPe5gIAv3fWVs8wDB9IpVIbOViz2SwHLUXxS1JkJUYrXhAELwSAns+qB4DjpZQM6zBrc4DrFmEYnpLL5Wy5snnF+5EQ4tgoH4p+HycPVLe5HIzl1bP6vfoeumPHjo0DAwOfBoAzLEaKBHkSacVbt27d84rFYs9UGTRyVrMVr7Kyv1cIYVUZTkRjvu9ztb5VU0rxSSjzrfdbb3ugKVmJ0YrH92qe5/VUXd1sz+7Pf/7zHpdeemnDItRCoXBIGIb3WD53p+1moVA4NgxDXvX6rbc9cD0iXtJqCpFWvJGRkfTixYunWinr8t9H4ptTSnHGgRVWTAzbzf6q1+UfogjmXYGI72vVL1LgsZIgCB4HgL1aKezW30elNFZKWaGq8bxdt5uV7S5vdXnL22+96YFIhQGRA08pxUflB/WmL8RliHhtFNsd32edtptV+7TW5xPRkgppyu5R7O736RoPnI+ILcHBTALvbiFEr7HZ/B4ALpFSft7ksSilOCv9KBOZal8iOtn3/W/byM4mwxf7qVRqfyIqf3met4i/V3JVq9/jGq6vx9EDrchKqupNAu8OIcRpjnYlKc7HxOV8QiLivMyvAMC3EdGYWNMlYTqO7aaJk0ZGRryFCxful8lk9g/DkAOzFqQAUA7MuoBNIg/WxNxdoW/LvGB2QuTAC4LgkwDA2592N65D48yER4joEc6i5/w/viitq03bFGcWfSdPN5N07ujo6B7z58/fr1Qq7cdBygFZDU7+Pm0lHUzSlrmquxVZifGKp7XOE5Efo8P4eqIcUEKI8s8AUP25XENWKpUeTCIdKMoclFIM13B0lL7T+3ie98JsNvt9G9lukeErJOZ2ICIO1EUAwF8zVtMurabomBvnzZu3b5Rax8grnlLqA0KIfzGdEQB8LwxD5vR+JJVKPVwsFnnVeggRHzXV1c7+Drj5sZxutnOuLmMppXYLw7AcpMVikUuaOHWO731nexf9G5exekF206ZNqZGREX7tadpMAo8ryZsiJzUY6VeIeEgrQ7rt9+vXrz90amrql5Z2xXK6aTl214pxPSavoLx68vdKgJZX1cphUW1VFUL03FYXALZJKYeiPIDIgedQGNizH0KllMtJ7rGI+OMoD6HfZ2cPTExMzJucnKwF6CxBWg1UPjxySk6P2fd/RMTnRNEZOfAKhcKrwzC8LYrSaX1CRExZyHVcJAiCywDgGhtD2n26aWPjXJBhwOUdO3Ysqr6PciByoHqeV11JyytrZUVNOgGkJVlJ1ecmgfeiMAyt7qc2bdqU6UVYgHw+f7jneT+3/ID27EpvOd+uFtuwYcPA5s2beSu7XzqdrgVlgyDld9WMxYS+hogviyIXOfC01odxMWkUpdP7hGG4qFOnkzb21su4sMOmUqkjhoeHrXzmandf3t4DtgkUUchKjFe8CpQe353ZtJ4iL5kWeO8QQtiSjaxBxDfbOKwv0zkP2BYlRyErMQ68ygvvUzbu6GV6qrGxsSNTqdTPbOYthOhvNy0d10kxpRR/zueZ2kBEV/u+H+nKLfJWk41QSnEt226mBoVh+KpcLtez0BG2SNrsp1Kp9PyVK1f+2tRn/f6d84At/k0UshLjFa8SePdXsC+NvEJEF/q+37NgSUqpdwohrjaadKUzAHxISnmpjWxfpv0ecKSlG/Z9f10Uq01XPN5yHRlF8bQ+b0XEnoUHdMHR7283LT4tHRRRSj1fCPG/NiYAwNlSys9GkTUKvCAI7mRChiiKp/V5HyIaA+JajJOYiNb6LiI6wWYAV+g/mzH7MnYeCILgxQDwLRvpKGQltlvNW4UQNUj2qMbNhctkl9xNIcRViMjcDP3W5R4IguAcAODcYuPmed5R2Wy2KVmJbeAVhBDDxhYJ8UlEfL2FXNeI5PP5YzzPs00B659uds2TbG5IEAQrAcCK0zEKWYlt4PF9Ft9rmbbIN/qmitvZXyn1PSHEiTZjMkFLLpdjHMd+62IPKKWsMW9aodjVT9v0Hc82d/HHiNjzYK0ulelCCCZ+qdYflmsPU6nUI82IVLr48zlnTVNKMYPvaosJRiIrsVrxtNZMmKhNjQKAP0kpexUoqTZdpRRjznDFQpyNoSk4IDdXC4M5KMMwLAcp/8xfk5OTD1100UV9Msk4PT+LLq31jUS01HQY5hb0fZ/ZeyM1oxXPgcrqL4jImeGRcOsjWd6hTi7bzRhM5gSGnVbNCiTGZg7USpA+NDU19WA/SO287cDaFImsxGrFU0qdIoT4hs2Upqam9u3Eh2Ht2rX7eJ63LwDsm06nnwjDkFeWRxHRCqBXa/1uImoJWGrjo5hlnq4L0hmrKQCUgaH6Qbqz15VS3xFC/KPFs/guIr4oqpzRiudykRwVBKaZ4Uophg7Yd/oXAOwz/f+IaGHl/2aoJKL7AeBaRFwb1VHVfkEQHAcADYlPTPV1Q38iKlbwbmaspqVS6WHP88rAUrtCkCqlGHXgUIvnEomsxGrFW79+/TOnpqbuszCKRXaCPbvpppt2n5ycZCiAfUul0kLP8xaGYbgQABZy0PB3XqWqPxNR7NB0AHBHOp32ly9f/geTOSmlmDnphSYyc6UvAFD1kIiINlcDllfQUqnE7K89HaS2lQlCiEhkJVaBx8Hy1FNP/cXyQ8SrBK9C/NVN6MjfFUKcYYK/qbW+goiutPTDLiVGRI9NW00fZmjGbgzSCkcIw0kaVyYIIT6KiG+N+nCNtpqsVCm1QwgxEHWAHul3KyKeE9XWfD5/vOd5DJrbbzF6gMGC6q5cGPKxjJ/ariB1rDmNRFZiteKxUBAE7AwGmZkzDQAmM5nMIhPObaUU42a+YM44ofcm8hcOUgDgAC1vb12D1BFZ7mKTMwObFc/25bPbH+1ZiBgZzMklw6HbHTEH7ePC1vIK2ixI582b9/xSqcSvHjYtElmJ9YrncNxqM5l2yrwLEa+KOuDNN9+81/bt2++yPAGLOky/X494ICpZiUvgfU4IcWaP+COymQAgpZScBB65Vei0bo4s0O84lz0QiazEOvCCIJgAgDfNNQ8S0Wt83+c/KkYtCILLASDySmmkvN+5Zzxgek9t/I6ntf4wEbXkeO4Zj/2VyfXXAPCPtnwOzGHneR4fJXORcNKgqb3k2l3J1oUmnx/jwFNKXSSEuGEueRQAVkgp18cxp0KhcCwRPatCecXAqHwCzN/rfzYGjIrDtr6O5DwQlazEeqvpeOSa3MztNX8CEc+zFzeXXLNmzV4DAwOLKkSSNQosDs4KZ12VaYeDtefIO8w90vMSjyOiUWaV8YrHLnLIZ+s2D1+JiFz42LVtYmJiweTkJBNIlgO1wrSz0/e61TTdtROZ24ZFJiuxXvFYUGvtE1G+R33JVwC3A8BdUsqv9ugcZjX7xhtv3GfHjh21IOWArAbqtK0ub3+t/ujOJX/FNRcAuFtKeZyJPmvnK6X4PY/f9zrZtgghuDj0UQB4jPMC638mokc9z3usVCo9Nm/evEcnJycfsy0H6uQkkxibGV/ryCNr759V5tfqtrfLaLCScEUcOj+FiEY05daBV9lyjgAAV6Uf4Gg9M2hy0MwIIv4/AHg0DEP+Xv59JpN57L777nssCvOmo127vDgRgdZ6p61u/epZ/05aKc/aFX22BBGNkMmcAq8SfFzujkR0JAAw2C2f6JWDpT6YKv9XCyz+Pa9E6XT6sT7uyNz4rHJ2/6JFi8oHQ5z7Wj3ZrX6ftu2NxJzaA565FxGfbWqnc+CZDtjv3/cAe2DNmjWDg4ODtQOj6YdG1VWV/7/L70aziDhu+lT7gWfqsX7/tntgw4YN8x9//PHyfSif7E47KKq/H+XftbPW88OI+HYbh/QDz8ZrfZmu9cDo6OgenLTAB0e8WnqeVw7UWe5HOWDnO0yEoUMus5XvB56t5/pyPe8BxvCZ7X50eqBWTn+5Mp3r/v4YhuG1uVyOwY2t2/8Hr+rCOm3min8AAAAASUVORK5CYII=";
   }
    }else{
    const imgs = document.getElementsByClassName("img" + i);
    for (let i1 = 0; i1 < imgs.length; i1++) {
    imgs[i1].src = pictures[i];
    }
    }
    }
}
  document.getElementById("author").innerHTML = author + "<br><p>null</p>";
  document.getElementById("authorImg").src = authorImg;
  break;
  }else if(i == data.length - 1){
  document.body.innerHTML = "资源不存在！";
  break;
  }
  } 
}
}
}
function download(){
  window.location.href=downloadURL;
  }
 </script>  
  </body>
</html>