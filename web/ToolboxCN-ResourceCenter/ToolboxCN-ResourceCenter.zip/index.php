<?php
$servername = "localhost";
$username = "root";
$password = "caofangkuai";
$dbname = "ToolboxCN";

$resultJSON = "";
 
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
 
$sql = "SELECT json FROM resourceList";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
         $resultJSON = $resultJSON . $row["json"];
    }
} else {
    $resultJSON = "0 结果";
}
$conn->close();
?>
<html>
 <head> 
  <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" /> 
  <title>ToolboxCN-资源中心</title>
  <script src="./js/jq.js"></script>
  <link rel="stylesheet" href="./css/mui.min.css" /> 
  <link rel="stylesheet" href="./css/mdui.min.css"/>
  <link href="./css/mui.indexedlist.css" rel="stylesheet" />  
 </head> 
 <body> 
 <div id="loading">
 <p style="z-index:999;position: absolute;top:65%;right:11%;color:#070200;font-size:20px;">加载中，请耐心等待…</p>
 <iframe src="./loading.html" style="width:100%;height:100%;position: absolute;top:0px;"></iframe>
 </div>
  <div class="mui-content" style="display:none" id="main"> 
   <div id="list" class="mui-indexed-list"> 
    <div class="mui-indexed-list-search mui-input-row mui-search"> 
     <input type="search" class="mui-input-clear mui-indexed-list-search-input" placeholder="搜索资源" /> 
    </div> 
    <div class="mui-indexed-list-bar" style="display:none;"></div> 
    <div class="mui-indexed-list-alert"></div>
    <div class="mui-indexed-list-inner"> 
     <div class="mui-indexed-list-empty-alert">
      该资源不存在
     </div> 
     <ul class="mui-table-view" id="listData1"> 
      <!--列表-->
     </ul> 
    </div> 
   </div>
   <div class="mdui-fab-wrapper" id="fab"> 
<button class="mdui-fab mdui-ripple mdui-color-pink-accent"> 
<i class="mdui-icon material-icons">&#xe254;</i> 
</button> 
<div class="mdui-fab-dial"> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-pink" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe145;</i>
</button> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-red" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe2c3;</i> 
</button> 
<button class="mdui-fab mdui-fab-mini mdui-ripple mdui-color-orange" mdui-dialog="{target: '#dialog-1'}">
<i class="mdui-icon material-icons">&#xe872;</i> 
</button> 
</div> 
</div>
<div class="mdui-dialog" id="dialog-1">
  <div class="mdui-dialog-title">操作提示</div>
  <div class="mdui-dialog-content">请联系ToolBoxCN官方进行 上传/更新/删除 等操作。</div>
  <div class="mdui-dialog-actions">
    <button class="mdui-btn mdui-ripple" mdui-dialog-confirm>确定</button>
  </div>
</div>
  </div>
  <script src="./js/mdui.min.js"></script>
  <script src="./js/mui.min.js"></script> 
  <script src="./js/mui.indexedlist.js"></script> 
   <script>
window.onload = function (){
mui.init();
document.getElementById("loading").style.display = "block";
document.getElementById("main").style.display = "none";
setTimeout(function() {
const data = <?php echo $resultJSON; ?>;
if(data == null || data == "" || data == undefined || data == "0 结果"){
document.body.innerHTML = "数据库加载失败";
}else{
const listData = document.getElementById("listData1");
document.getElementById("loading").style.display = "none";
document.getElementById("main").style.display = "block";
var inst = new mdui.Fab('#fab');
for (let i = 0; i < data.length; i++) { 
  const item = data[i]; 
  const name = item["name"];
  const type = item["type"];
  const smallIcon = item["smallIcon"];
  const id = item["id"];
  listData.innerHTML += '<li class="mui-table-view-cell mui-media mui-indexed-list-item"><a href="javascript:window.location.href = ' + "'" + 'download.php?id=' + id + "'" + ';"><img class="mui-media-object mui-pull-left"src="' + smallIcon + '"/><div class="mui-media-body">' + name + '<p class="mui-ellipsis">' + type + '</p></div></a></li>';
  }
   mui.ready(function() {
	var list = document.getElementById('list');
	//calc hieght
	list.style.height = document.body.offsetHeight + 'px';
	//create
	window.indexedList = new mui.IndexedList(list);
    });
}
}, 1800);
}
   </script>
 </body>
</html>